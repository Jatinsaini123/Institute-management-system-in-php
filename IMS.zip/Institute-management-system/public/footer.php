          <p class="text-center text-sm text-gray-500 my-10 bottom-0 inset-x-0">
            
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
