$("li").click(function(){
    $("li").addClass("bg-gradient-to-r from-sky-600 to-cyan-400");
});