<?php 
include("../actions/checkadmin.php");
include("../public/header.php");
include("../includes/config.php");

// Set timezone
date_default_timezone_set("Asia/Calcutta");
$todaysDate = date("m-d-Y");
?>

<style>
    :root {
        --primary-color: #2563eb;
        --danger-color: #dc2626;
        --success-color: #16a34a;
        --background-color: #f8fafc;
        --text-primary: #1e293b;
        --text-secondary: #64748b;
        --border-color: #e2e8f0;
    }

    .content-wrapper {
        background: white;
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 2rem;
        padding: 1.5rem;
        animation: fadeIn 0.5s ease-out;
    }

    .form-container {
        background: white;
        padding: 2rem;
        border-radius: 0.5rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-label {
        font-size: 0.875rem;
        font-weight: 500;
        color: var(--text-primary);
    }

    .form-select, .form-input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid var(--border-color);
        border-radius: 0.5rem;
        background-color: white;
        transition: all 0.3s ease;
    }

    .form-select:focus, .form-input:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.1);
        outline: none;
    }

    .submit-btn {
        background: linear-gradient(45deg, var(--primary-color), #1d4ed8);
        color: white;
        padding: 0.75rem 2rem;
        border-radius: 0.5rem;
        border: none;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(37, 99, 235, 0.2);
    }

    .attendance-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin-top: 2rem;
    }

    .attendance-table th {
        background: linear-gradient(45deg, #1e293b, #334155);
        color: white;
        padding: 1rem;
        text-align: left;
        font-size: 0.875rem;
        font-weight: 600;
    }

    .attendance-table td {
        padding: 1rem;
        border-bottom: 1px solid var(--border-color);
    }

    .attendance-table tr:hover {
        background-color: #f8fafc;
    }

    .checkbox-group {
        display: flex;
        gap: 1rem;
        align-items: center;
    }

    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
    }

    .checkbox-input {
        width: 1.25rem;
        height: 1.25rem;
        border-radius: 0.25rem;
        border: 2px solid var(--border-color);
        transition: all 0.2s ease;
    }

    .checkbox-input:checked {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 768px) {
        .form-grid {
            grid-template-columns: 1fr;
        }
        
        .attendance-table {
            font-size: 0.875rem;
        }
    }
</style>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php"); ?>

    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main class="p-6">
            <div class="content-wrapper">
                <div class="mb-6">
                    <h3 class="text-xl font-bold text-gray-900">
                        Attendance (Today's Date: <?php echo $todaysDate; ?>)
                    </h3>
                </div>

                <form action="" method="POST" class="form-container">
                    <div class="form-grid">
                        <!-- Year Selection -->
                        <div class="form-group">
                            <label class="form-label">Year</label>
                            <select name="year" class="form-select">
                                <option value="">Select Year</option>
                                <?php
                                $years = mysqli_query($db_conn, "SELECT * FROM years");
                                while ($year = mysqli_fetch_object($years)) {
                                    echo "<option value='{$year->id}'>{$year->year}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Department Selection -->
                        <div class="form-group">
                            <label class="form-label">Department</label>
                            <select name="dept" class="form-select">
                                <option value="">Select Department</option>
                                <?php
                                $departments = mysqli_query($db_conn, "SELECT * FROM department");
                                while ($dept = mysqli_fetch_object($departments)) {
                                    echo "<option value='{$dept->id}'>" . ucfirst($dept->name) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Section Selection -->
                        <div class="form-group">
                            <label class="form-label">Section</label>
                            <select name="sec" class="form-select">
                                <option value="">Select Section</option>
                                <?php
                                $sections = mysqli_query($db_conn, "SELECT * FROM section");
                                while ($section = mysqli_fetch_object($sections)) {
                                    echo "<option value='{$section->id}'>" . ucfirst($section->name) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Subject Selection -->
                        <div class="form-group">
                            <label class="form-label">Subject</label>
                            <select name="sub" class="form-select">
                                <option value="">Select Subject</option>
                                <?php
                                $subjects = mysqli_query($db_conn, "SELECT * FROM subject");
                                while ($subject = mysqli_fetch_object($subjects)) {
                                    echo "<option value='{$subject->id}'>" . ucfirst($subject->name) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Date Selection -->
                        <div class="form-group">
                            <label class="form-label">Date</label>
                            <input type="date" name="date" class="form-input" 
                                   value="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>

                    <button type="submit" name="takeattendance" class="submit-btn">
                        Take Attendance
                    </button>
                </form>

                <?php if(isset($_POST['takeattendance'])): ?>
                    <!-- Attendance Table -->
                    <div class="mt-8">
                        <form method="POST">
                            <table class="attendance-table">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Roll No</th>
                                        <th>Student Name</th>
                                        <th>Attendance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "SELECT * FROM user, student 
                                             WHERE user.user_type='student' 
                                             AND user.id = student.id 
                                             AND student.yearid = {$_POST['year']}
                                             AND student.departmentid = {$_POST['dept']}
                                             AND student.sectionid = {$_POST['sec']}";
                                    
                                    $students = mysqli_query($db_conn, $query);
                                    while($student = mysqli_fetch_object($students)):
                                    ?>
                                    <tr>
                                        <td><?php echo $student->id; ?></td>
                                        <td><?php echo $student->rollno; ?></td>
                                        <td><?php echo ucfirst($student->firstname) . ' ' . ucfirst($student->lastname); ?></td>
                                        <td>
                                            <div class="checkbox-group">
                                                <label class="checkbox-label">
                                                    <input type="radio" name="attendance[<?php echo $student->id; ?>]" 
                                                           value="P" class="checkbox-input" required>
                                                    Present
                                                </label>
                                                <label class="checkbox-label">
                                                    <input type="radio" name="attendance[<?php echo $student->id; ?>]" 
                                                           value="A" class="checkbox-input">
                                                    Absent
                                                </label>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>

                            <!-- Hidden fields for form data -->
                            <input type="hidden" name="year" value="<?php echo $_POST['year']; ?>">
                            <input type="hidden" name="dept" value="<?php echo $_POST['dept']; ?>">
                            <input type="hidden" name="sec" value="<?php echo $_POST['sec']; ?>">
                            <input type="hidden" name="sub" value="<?php echo $_POST['sub']; ?>">
                            <input type="hidden" name="date" value="<?php echo $_POST['date']; ?>">

                            <div class="mt-6 text-center">
                                <button type="submit" name="submitattendance" class="submit-btn">
                                    Submit Attendance
                                </button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>

<?php include("../public/footer.php"); ?>