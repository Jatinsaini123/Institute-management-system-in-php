<!-- Common Header -->
<?php include("../actions/checkadmin.php")?>
<?php include("../public/header.php")?>
<?php include("../includes/config.php") ?>
<link rel="stylesheet" href="admin-style.css">

<?php
$message = '';

if (isset($_POST['querysubmit'])) {
    $Dept = $_POST['Department'];

    // Prepare and bind
    $stmt = $db_conn->prepare("INSERT INTO department (name) VALUES (?)");
    $stmt->bind_param("s", $Dept);

    if ($stmt->execute()) {
        $message = "Department '$Dept' added successfully.";
    } else {
        $message = "Failed to add department.";
    }
}

// Fetch data for Pie Chart
$chartQuery = "SELECT name, COUNT(*) as total FROM department GROUP BY name";
$chartResult = mysqli_query($db_conn, $chartQuery);
$labels = [];
$counts = [];

while ($row = mysqli_fetch_assoc($chartResult)) {
    $labels[] = $row['name'];
    $counts[] = $row['total'];
}

// Fetch total counts
$studentCount = mysqli_fetch_object(mysqli_query($db_conn, "SELECT COUNT(*) as total FROM student"))->total;
$teacherCount = mysqli_fetch_object(mysqli_query($db_conn, "SELECT COUNT(*) as total FROM teacher"))->total;
$adminCount = mysqli_fetch_object(mysqli_query($db_conn, "SELECT COUNT(*) as total FROM user WHERE user_type = 'admin'"))->total;
$departmentCount = mysqli_fetch_object(mysqli_query($db_conn, "SELECT COUNT(*) as total FROM department"))->total;
?>

<div class="flex overflow-hidden bg-white">
  
<!-- Aside | Sidebar -->
<?php include("sidebar.php")?>

  <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

  <div id="main-content" class="h-full w-full relative overflow-y-auto lg:ml-64">
    <main class="dashboard-container">
      <div class="pt-6">
        <!-- Welcome Section -->
        <div class="mb-8">
          <h1 class="text-3xl font-bold gradient-text">Welcome to Dashboard</h1>
          <p class="text-gray-600 mt-2">Monitor and manage your institute's data</p>
        </div>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          <!-- Stats Card 1 -->
          <div class="stats-card" data-tooltip="Total number of students">
            <div class="flex items-center p-6">
              <div class="flex-shrink-0">
                <span class="stats-number"><?php echo $studentCount; ?></span>
                <h3 class="text-base font-normal text-gray-500">Total Students</h3>
              </div>
              <div class="ml-5 flex-1 flex items-center justify-end text-green-500 font-bold text-base">
                <svg class="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                </svg>
              </div>
            </div>
          </div>

          <!-- Stats Card 2 -->
          <div class="stats-card" data-tooltip="Total number of teachers">
            <div class="flex items-center p-6">
              <div class="flex-shrink-0">
                <span class="stats-number"><?php echo $teacherCount; ?></span>
                <h3 class="text-base font-normal text-gray-500">Total Teachers</h3>
              </div>
              <div class="ml-5 flex-1 flex items-center justify-end text-green-500 font-bold text-base">
                <svg class="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                </svg>
              </div>
            </div>
          </div>

          <!-- Stats Card 3 -->
          <div class="stats-card" data-tooltip="Total number of admins">
            <div class="flex items-center p-6">
              <div class="flex-shrink-0">
                <span class="stats-number"><?php echo $adminCount; ?></span>
                <h3 class="text-base font-normal text-gray-500">Total Admins</h3>
              </div>
              <div class="ml-5 flex-1 flex items-center justify-end text-green-500 font-bold text-base">
                <svg class="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                </svg>
              </div>
            </div>
          </div>

          <!-- Stats Card 4 -->
          <div class="stats-card" data-tooltip="Total number of departments">
            <div class="flex items-center p-6">
              <div class="flex-shrink-0">
                <span class="stats-number"><?php echo $departmentCount; ?></span>
                <h3 class="text-base font-normal text-gray-500">Total Departments</h3>
              </div>
              <div class="ml-5 flex-1 flex items-center justify-end text-green-500 font-bold text-base">
                <svg class="w-5 h-5 ml-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 2xl:grid-cols-2 gap-6 mt-8">
          <!-- Add Department Form -->
          <div class="form-container">
            <h3 class="chart-title">Add a new Department</h3>
            <?php if (!empty($message)) : ?>
              <div class="success-message"><?= $message ?></div>
            <?php endif; ?>
            <form action="" method="POST" class="max-w-md mx-auto mt-6">
              <div class="mb-6">
                <label class="form-label" for="department">
                  Department Name
                </label>
                <input class="form-input"
                  id="department" 
                  type="text" 
                  name="Department" 
                  placeholder="Enter new Department" 
                  required />
              </div>
              <div class="flex items-center justify-center">
                <button class="submit-button" type="submit" name="querysubmit">
                  Add Department
                </button>
              </div>
            </form>
          </div>

          <!-- Department Pie Chart -->
          <div class="chart-container">
            <h3 class="chart-title">Departments Overview</h3>
            <div class="block w-full overflow-x-auto">
              <canvas class="p-1" id="chartPie"></canvas>
              <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
              <script>
                const dataPie = {
                  labels: <?= json_encode($labels); ?>,
                  datasets: [{
                    label: "Departments",
                    data: <?= json_encode($counts); ?>,
                    backgroundColor: ["#164B60", "#435B66", "#1B6B93", "#19A7CE", "#146C94", "#4682A9"],
                    hoverOffset: 4,
                  }]
                };

                const configPie = {
                  type: "pie",
                  data: dataPie,
                  options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                        labels: {
                          padding: 20,
                          font: {
                            size: 12
                          }
                        }
                      },
                      tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        borderRadius: 4,
                        titleFont: {
                          size: 14
                        },
                        bodyFont: {
                          size: 13
                        }
                      }
                    },
                    animation: {
                      animateScale: true,
                      animateRotate: true,
                      duration: 2000,
                      easing: 'easeInOutQuart'
                    }
                  }
                };

                new Chart(document.getElementById("chartPie"), configPie);
              </script>
            </div>
          </div>
        </div>
      </div>
    </main>
<?php include("../public/footer.php") ?>
  </div>
</div>
