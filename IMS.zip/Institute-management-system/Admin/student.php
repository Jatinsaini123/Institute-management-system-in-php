<?php include("../actions/checkadmin.php") ?>
<?php include("../public/header.php")?>
<?php include("../includes/config.php") ?>
<?php
if (isset($_POST['delete'])) {
    $id = $_POST['delete'];
    mysqli_query($db_conn, "DELETE FROM user WHERE user.id = $id;") or die("Deletion user not possible");
    mysqli_query($db_conn, "DELETE FROM student WHERE student.id = $id;") or die("Deletion student not possible");
}
?>

<style>
    :root {
        --primary-color: #2563eb;
        --danger-color: #dc2626;
        --success-color: #16a34a;
        --background-color: #f8fafc;
        --text-primary: #1e293b;
        --text-secondary: #64748b;
        --border-color: #e2e8f0;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: var(--background-color);
        margin: 0;
        padding: 0;
        min-height: 100vh;
    }

    #main-content {
        margin-left: 16rem;
        padding: 2rem;
        min-height: 100vh;
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        transition: margin-left 0.3s ease;
    }

    .content-wrapper {
        background: white;
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 
                    0 2px 4px -1px rgba(0, 0, 0, 0.06);
        margin-bottom: 2rem;
        padding: 1.5rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        animation: fadeIn 0.5s ease-out;
    }

    .header-section {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.5rem 2.5rem;
        border-bottom: 2px solid var(--border-color);
        margin-bottom: 1.5rem;
        background: linear-gradient(to right, #ffffff, #f8fafc);
    }

    .header-section h3 {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--text-primary);
        text-transform: uppercase;
        letter-spacing: 0.025em;
        margin: 0;
        background: linear-gradient(45deg, var(--primary-color), #1d4ed8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .add-new-btn {
        padding: 0.75rem 1.5rem;
        background: linear-gradient(45deg, var(--primary-color), #1d4ed8);
        color: white;
        border-radius: 0.5rem;
        font-weight: 500;
        text-decoration: none;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);
    }

    .table-container {
        padding: 0 1.5rem;
        overflow-x: auto;
        scrollbar-width: thin;
        scrollbar-color: var(--primary-color) var(--border-color);
    }

    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        white-space: nowrap;
    }

    thead {
        background: linear-gradient(45deg, #1e293b, #334155);
        position: sticky;
        top: 0;
        z-index: 10;
    }

    th {
        text-align: left;
        padding: 1.5rem 2.5rem;
        font-size: 0.875rem;
        font-weight: 600;
        text-transform: uppercase;
        color: white;
        letter-spacing: 0.05em;
    }

    td {
        padding: 1.5rem 2.5rem;
        color: var(--text-primary);
        font-size: 0.95rem;
        border-bottom: 1px solid var(--border-color);
        transition: all 0.2s ease;
    }

    tbody tr {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    tbody tr:hover {
        background: linear-gradient(to right, #f8fafc, #ffffff);
        transform: scale(1.01);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .delete-btn {
        display: inline-flex;
        align-items: center;
        padding: 0.75rem 1.5rem;
        background: linear-gradient(45deg, var(--danger-color), #b91c1c);
        color: white;
        border-radius: 0.5rem;
        font-size: 0.95rem;
        font-weight: 500;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(220, 38, 38, 0.2);
    }

    .delete-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(220, 38, 38, 0.3);
    }

    .delete-btn svg {
        width: 1.25rem;
        height: 1.25rem;
        margin-right: 0.75rem;
        transition: transform 0.3s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 1024px) {
        #main-content {
            margin-left: 0;
            padding: 1rem;
        }

        .header-section {
            flex-direction: column;
            gap: 1rem;
            padding: 1rem;
        }
    }
</style>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="content-wrapper">
                <div class="header-section">
                    <h3>Student Management</h3>
                    <a href="newstudent.php" class="add-new-btn">Add new Student</a>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 10%">ID</th>
                                <th style="width: 25%">Name</th>
                                <th style="width: 25%">Department</th>
                                <th style="width: 15%">Section</th>
                                <th style="width: 15%">Year</th>
                                <th style="width: 10%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $extract_user_query = 'SELECT * FROM user,student WHERE user.user_type="student" AND user.id = student.id';
                            $result = mysqli_query($db_conn, $extract_user_query);
                            while ($row = mysqli_fetch_object($result)) {
                                $dept = mysqli_fetch_object(mysqli_query($db_conn, "SELECT name FROM department WHERE id = '$row->departmentid'"));
                                $section = mysqli_fetch_object(mysqli_query($db_conn, "SELECT name FROM section WHERE id = '$row->sectionid'"));
                                $year = mysqli_fetch_object(mysqli_query($db_conn, "SELECT year FROM years WHERE id = '$row->yearid'"));
                            ?>
                            <tr>
                                <td><?php echo $row->id; ?></td>
                                <td><?php echo ucfirst($row->firstname) . ' ' . ucfirst($row->lastname); ?></td>
                                <td><?php echo ucwords($dept->name); ?></td>
                                <td><?php echo ucwords($section->name); ?></td>
                                <td><?php echo $year->year; ?></td>
                                <td>
                                    <form method="POST">
                                        <button name="delete" type="submit" value="<?php echo $row->id; ?>" class="delete-btn">
                                            <svg fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                                            </svg>
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
        <?php include("../public/footer.php")?>
    </div>
</div>