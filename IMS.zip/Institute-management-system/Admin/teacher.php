<?php include("../actions/checkadmin.php") ?>
<?php include("../public/header.php")?>
<?php include("../includes/config.php") ?>
<?php
if (isset($_POST['delete'])) {
    $id = $_POST['delete'];
    mysqli_query($db_conn, "DELETE FROM user WHERE user.id = $id;") or die("Deletion user not possible");
    mysqli_query($db_conn, "DELETE FROM teacher WHERE teacher.id = $id;") or die("Deletion teacher not possible");
}

if (isset($_POST['allotteacher'])) {
    $tea = $_POST['tea'];
    $dept = $_POST['dept'];
    $year = $_POST['year'];
    $sec = $_POST['sec'];
    $sub = $_POST['sub'];

    $sql = "SELECT * FROM allotment WHERE teacherid = '$tea' AND yearid = '$year' AND departmentid = '$dept' AND sectionid = '$sec' ";
    $res = mysqli_query($db_conn, $sql) or die(mysqli_error($db_conn));
    $row = mysqli_fetch_object($res);
    if (!mysqli_num_rows($res)) {
        mysqli_query($db_conn, "INSERT INTO allotment (teacherid, yearid, departmentid, sectionid, subjectid) VALUES ('".$tea . "', '" . $year . "', '" . $dept . "', '" . $sec . "', '" . $sub . "')") or die(mysqli_error($db_conn));
    } else {
        echo "Already Existed";
        header('Location: teacher.php');
    }
    header('Location: teacher.php');
}
?>

<style>
    :root {
        --primary-color: #2563eb;
        --danger-color: #dc2626;
        --success-color: #16a34a;
        --background-color: #f8fafc;
        --text-primary: #1e293b;
        --text-secondary: #64748b;
        --border-color: #e2e8f0;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: var(--background-color);
        margin: 0;
        padding: 0;
        min-height: 100vh;
    }

    #main-content {
        margin-left: 16rem;
        padding: 2rem;
        min-height: 100vh;
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        transition: margin-left 0.3s ease;
    }

    .content-wrapper {
        background: white;
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 
                    0 2px 4px -1px rgba(0, 0, 0, 0.06);
        margin-bottom: 2rem;
        padding: 1.5rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        animation: fadeIn 0.5s ease-out;
    }

    .header-section {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.5rem 2.5rem;
        border-bottom: 2px solid var(--border-color);
        margin-bottom: 1.5rem;
        background: linear-gradient(to right, #ffffff, #f8fafc);
    }

    .header-section h3 {
        font-size: 1.75rem;
        font-weight: 700;
        background: linear-gradient(45deg, var(--primary-color), #1d4ed8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
    }

    .table-container {
        padding: 0 1.5rem;
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        white-space: nowrap;
    }

    thead {
        background: linear-gradient(45deg, #1e293b, #334155);
        position: sticky;
        top: 0;
        z-index: 10;
    }

    th {
        text-align: left;
        padding: 1.5rem 2.5rem;
        color: white;
        font-size: 0.875rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    td {
        padding: 1.5rem 2.5rem;
        color: var(--text-primary);
        font-size: 0.95rem;
        border-bottom: 1px solid var(--border-color);
    }

    tbody tr {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    tbody tr:hover {
        background: linear-gradient(to right, #f8fafc, #ffffff);
        transform: scale(1.01);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .delete-btn {
        display: inline-flex;
        align-items: center;
        padding: 0.75rem 1.5rem;
        background: linear-gradient(45deg, var(--danger-color), #b91c1c);
        color: white;
        border-radius: 0.5rem;
        font-size: 0.95rem;
        font-weight: 500;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(220, 38, 38, 0.2);
    }

    .delete-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(220, 38, 38, 0.3);
    }

    .delete-btn svg {
        width: 1.25rem;
        height: 1.25rem;
        margin-right: 0.75rem;
    }

    /* Allotment Form Styles */
    .allotment-form {
        background: white;
        padding: 2rem;
        border-radius: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .form-grid {
        display: grid;
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-label {
        font-size: 0.875rem;
        font-weight: 500;
        color: var(--text-primary);
    }

    .form-select {
        padding: 0.75rem 1rem;
        border: 1px solid var(--border-color);
        border-radius: 0.5rem;
        background-color: white;
        transition: all 0.3s ease;
    }

    .form-select:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.1);
        outline: none;
    }

    .submit-btn {
        background: linear-gradient(45deg, var(--primary-color), #1d4ed8);
        color: white;
        padding: 0.75rem 2rem;
        border-radius: 0.5rem;
        border: none;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(37, 99, 235, 0.2);
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 1024px) {
        #main-content {
            margin-left: 0;
            padding: 1rem;
        }

        .header-section {
            flex-direction: column;
            gap: 1rem;
            padding: 1rem;
        }

        .form-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="content-wrapper">
                <div class="header-section">
                    <h3>Teacher Management</h3>
                    <a href="newteacher.php" class="add-new-btn">Add new Teacher</a>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone no.</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $extract_user_query = 'SELECT * FROM user WHERE user_type="teacher"';
                            $result = mysqli_query($db_conn, $extract_user_query);
                            while ($row = mysqli_fetch_object($result)) {
                            ?>
                            <tr>
                                <td><?php echo $row->id; ?></td>
                                <td><?php echo ucfirst($row->firstname) . ' ' . ucfirst($row->lastname); ?></td>
                                <td><?php echo $row->email; ?></td>
                                <td><?php echo $row->phone; ?></td>
                                <td>
                                    <form method="POST">
                                        <button name="delete" type="submit" value="<?php echo $row->id; ?>" class="delete-btn">
                                            <svg fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                                            </svg>
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Teacher Allotment Form -->
            
                
                <form method="POST" class="form-grid">
                    <!-- Form fields here with the same styling -->
                    <!-- Add your existing form fields here with the new classes -->
                </form>
            </div>
        </main>
        <?php include("../public/footer.php")?>
    </div>
</div>