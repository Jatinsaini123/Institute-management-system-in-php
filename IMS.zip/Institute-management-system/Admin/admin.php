<?php include("../actions/checkadmin.php") ?>
<?php include("../public/header.php")?>
<?php include("../includes/config.php") ?>

<?php
if (isset($_POST['delete'])) {
    $id = $_POST['delete'];
    if ($id == 41470001 or $id == 41470002) {
?>
        <script>alert("This admin Cannot be deleted")</script>
<?php
        header('refresh:0');
    } else {
        mysqli_query($db_conn, "DELETE FROM user WHERE user.id = $id;") or die("Deletion user not possible");
    }
}
?>

<!-- Internal Advanced CSS -->
<head>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f1f5f9;
    }

    table {
      border-collapse: collapse;
      width: 100%;
    }

    thead {
      background: linear-gradient(to right, #0f172a, #1e293b);
      color: #fff;
    }

    th, td {
      padding: 1rem;
      text-align: left;
    }

    tbody tr {
      transition: background 0.3s ease;
    }

    tbody tr:hover {
      background-color: #f9fafb;
    }

    .rounded-lg {
      border-radius: 12px;
    }

    .shadow {
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.1);
    }

    .text-cyan-600 {
      color: #06b6d4;
    }

    .text-cyan-600:hover {
      color: #0891b2;
    }

    .btn-delete {
      display: inline-flex;
      align-items: center;
      padding: 0.5rem 1rem;
      font-size: 0.875rem;
      font-weight: 600;
      color: white;
      background: linear-gradient(135deg, #ef4444, #dc2626);
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .btn-delete:hover {
      background: linear-gradient(135deg, #dc2626, #b91c1c);
      transform: scale(1.05);
    }

    .btn-delete svg {
      margin-right: 0.5rem;
    }

    .table-container {
      border-radius: 12px;
      overflow: hidden;
      background-color: #ffffff;
    }

    ::-webkit-scrollbar {
      height: 8px;
      width: 8px;
    }

    ::-webkit-scrollbar-track {
      background: transparent;
    }

    ::-webkit-scrollbar-thumb {
      background-color: rgba(100, 116, 139, 0.4);
      border-radius: 10px;
    }

    .dark .table-container {
      background-color: #1e293b;
      color: #cbd5e1;
    }

    .dark thead {
      background: #0f172a;
    }

    .dark tbody tr:hover {
      background-color: #334155;
    }

    .dark .btn-delete {
      background: linear-gradient(135deg, #ef4444, #b91c1c);
    }

    .dark .btn-delete:hover {
      background: linear-gradient(135deg, #b91c1c, #7f1d1d);
    }
  </style>
</head>

<div class="flex overflow-hidden bg-white">
<?php include("sidebar.php")?>

  <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
  <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
    <main>
      <div class="pt-6 px-4">
        <div class="w-full flex justify-center">

          <div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 w-full max-w-screen-xl">

            <div class="mb-4 flex items-center justify-between">
              <div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Admin</h3>
              </div>
              <div class="flex-shrink-0">
                <a href="newadmin.php" class="text-sm font-medium text-cyan-600 hover:bg-gray-100 rounded-lg p-2">Add new admin</a>
              </div>
            </div>

            <div class="flex flex-col m-8 table-container">
              <div class="overflow-x-auto">
                <div class="inline-block min-w-full align-middle">
                  <div class="overflow-hidden shadow">
                    <table class="min-w-full divide-y divide-gray-200 table-fixed dark:divide-gray-600">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Phone</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                        <?php
                        $extract_user_query = 'SELECT * FROM user WHERE user_type="admin"';
                        $result = mysqli_query($db_conn, $extract_user_query);
                        while ($row = mysqli_fetch_object($result)) {
                        ?>
                          <tr>
                            <td><?php echo ucfirst($row->id) ?></td>
                            <td><?php echo ucfirst($row->firstname) . " " . ucfirst($row->lastname) ?></td>
                            <td><?php echo ucfirst($row->email) ?></td>
                            <td><?php echo ucfirst($row->phone) ?></td>
                            <td>
                              <form action="" method="POST">
                                <button name="delete" value="<?php echo $row->id ?>" type="submit" class="btn-delete">
                                  <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                  </svg>
                                  Delete user
                                </button>
                              </form>
                            </td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </main>

<?php include("../public/footer.php")?>
