<?php include("../actions/checkstudent.php") ?>
<?php include("../public/header.php") ?>
<?php include("../includes/config.php") ?>

<div class="flex overflow-hidden bg-white">
    <!-- Sidebar -->
    <?php include("sidebar.php") ?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="pt-6 px-4">
                <div class="w-full grid grid-cols-1 gap-4">
                    <div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8">
                        <!-- Header -->
                        <div class="mb-4 flex items-center justify-between">
                            <div>
                                <h3 class="text-xl font-bold text-gray-900 mb-2">My Courses</h3>
                                <p class="text-sm text-gray-500">View all your enrolled courses and materials</p>
                            </div>
                        </div>

                        <!-- Courses Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <?php
                            $email = $_SESSION['useremail'];
                            // Get student details including department and year
                            $user_query = "SELECT user.id as id, student.departmentid as departmentid, student.yearid as yearid 
                                         FROM user, student 
                                         WHERE email = '$email' AND user.id = student.id";
                            $user_result = mysqli_query($db_conn, $user_query);
                            $user_row = mysqli_fetch_object($user_result);

                            // Get all subjects for student's department
                            $subjects_query = "SELECT subject.*, department.name as dept_name 
                                            FROM subject 
                                            LEFT JOIN department ON subject.departmentid = department.id
                                            WHERE subject.departmentid = '$user_row->departmentid'
                                            ORDER BY subject.name ASC";
                            $subjects_result = mysqli_query($db_conn, $subjects_query);

                            while ($subject = mysqli_fetch_object($subjects_result)) {
                                // Get course materials count
                                $materials_query = "SELECT COUNT(*) as count 
                                                  FROM course_materials 
                                                  WHERE subject_id = '$subject->id'";
                                $materials_result = mysqli_query($db_conn, $materials_query);
                                $materials_count = mysqli_fetch_object($materials_result)->count;
                            ?>
                                <div class="bg-white border rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                                    <div class="p-5">
                                        <div class="flex items-center justify-between mb-3">
                                            <div class="flex items-center">
                                                <div class="inline-flex items-center justify-center w-12 h-12 mr-3 rounded-full bg-blue-50">
                                                    <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                              d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                                    </svg>
                                                </div>
                                                <div>
                                                    <h4 class="text-lg font-semibold text-gray-900">
                                                        <?php echo htmlspecialchars($subject->name); ?>
                                                    </h4>
                                                    <p class="text-sm text-gray-500">
                                                        <?php echo htmlspecialchars($subject->dept_name); ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <span class="px-3 py-1 text-sm text-blue-600 bg-blue-100 rounded-full">
                                                <?php echo $materials_count; ?> Materials
                                            </span>
                                        </div>

                                        <p class="text-gray-600 text-sm mb-4">
                                            <?php echo htmlspecialchars($subject->description ?? 'No description available.'); ?>
                                        </p>

                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center space-x-2">
                                                <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                </svg>
                                                <span class="text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($subject->credits ?? 'N/A'); ?> Credits
                                                </span>
                                            </div>
                                            <a href="course-details.php?id=<?php echo $subject->id; ?>" 
                                               class="inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-colors duration-300">
                                                View Details
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>

                        <?php if (mysqli_num_rows($subjects_result) == 0): ?>
                        <div class="text-center py-12">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">No courses found</h3>
                            <p class="mt-1 text-sm text-gray-500">No courses are currently assigned to your department.</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include("../public/footer.php") ?>
