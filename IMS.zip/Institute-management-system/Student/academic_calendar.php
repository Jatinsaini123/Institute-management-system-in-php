<?php 
include("../actions/checkadmin.php");
include("../public/header.php");
include("../includes/config.php");

// Fetch all academic events from database
$events = array();

// Fetch exams
$examQuery = "SELECT * FROM exams";
$examResult = mysqli_query($db_conn, $examQuery);
while ($row = mysqli_fetch_assoc($examResult)) {
    $events[] = array(
        'id' => 'exam_' . $row['id'],
        'title' => 'Exam: ' . $row['subject_name'],
        'start' => $row['exam_date'],
        'end' => $row['exam_date'],
        'description' => $row['description'],
        'type' => 'exam',
        'className' => 'exam-event',
        'color' => '#ef4444' // Red color for exams
    );
}

// Fetch holidays
$holidayQuery = "SELECT * FROM holidays";
$holidayResult = mysqli_query($db_conn, $holidayQuery);
while ($row = mysqli_fetch_assoc($holidayResult)) {
    $events[] = array(
        'id' => 'holiday_' . $row['id'],
        'title' => 'Holiday: ' . $row['holiday_name'],
        'start' => $row['start_date'],
        'end' => $row['end_date'],
        'description' => $row['description'],
        'type' => 'holiday',
        'className' => 'holiday-event',
        'color' => '#10b981' // Green color for holidays
    );
}

// Fetch assignments
$assignmentQuery = "SELECT * FROM assignments";
$assignmentResult = mysqli_query($db_conn, $assignmentQuery);
while ($row = mysqli_fetch_assoc($assignmentResult)) {
    $events[] = array(
        'id' => 'assignment_' . $row['id'],
        'title' => 'Assignment: ' . $row['title'],
        'start' => $row['due_date'],
        'end' => $row['due_date'],
        'description' => $row['description'],
        'subject' => $row['subject'],
        'type' => 'assignment',
        'className' => 'assignment-event',
        'color' => '#6366f1' // Indigo color for assignments
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Calendar - Institute Management System</title>
    
    <!-- FullCalendar Dependencies -->
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.4.0/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.4.0/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@4.4.0/main.min.css' rel='stylesheet' />
    <link href='https://cdn.jsdelivr.net/npm/@fullcalendar/list@4.4.0/main.min.css' rel='stylesheet' />
    
    <!-- Custom Calendar Styles -->
    <style>
        .calendar-container {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin: 2rem;
        }

        .calendar-header {
            margin-bottom: 2rem;
        }

        .filter-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        .filter-tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #f3f4f6;
            border: none;
            font-weight: 500;
        }

        .filter-tab:hover {
            background: #e5e7eb;
            transform: translateY(-2px);
        }

        .filter-tab.active-tab {
            background: #164B60;
            color: white;
        }

        .event-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 1rem;
            max-width: 500px;
            width: 90%;
            position: relative;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .close-button {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
            transition: color 0.3s ease;
        }

        .close-button:hover {
            color: #000;
        }

        .modal-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #164B60;
        }

        .modal-date {
            color: #666;
            margin-bottom: 1rem;
            font-size: 0.95rem;
        }

        .modal-description {
            line-height: 1.6;
            color: #333;
        }

        .modal-subject {
            margin-top: 1rem;
            color: #666;
            font-style: italic;
            border-top: 1px solid #eee;
            padding-top: 1rem;
        }

        .animate-fade-in {
            animation: fadeIn 0.3s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #calendar {
            min-height: 700px;
        }

        .exam-event {
            border-radius: 4px;
            border: none !important;
        }

        .holiday-event {
            border-radius: 4px;
            border: none !important;
        }

        .assignment-event {
            border-radius: 4px;
            border: none !important;
        }

        .event-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 1rem;
        }

        .event-badge.exam {
            background-color: #fecaca;
            color: #ef4444;
        }

        .event-badge.holiday {
            background-color: #d1fae5;
            color: #10b981;
        }

        .event-badge.assignment {
            background-color: #e0e7ff;
            color: #6366f1;
        }

        @media (max-width: 768px) {
            .calendar-container {
                margin: 1rem;
                padding: 1rem;
            }

            .filter-tabs {
                gap: 0.5rem;
            }

            .filter-tab {
                padding: 0.5rem 1rem;
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>
    <div class="flex overflow-hidden bg-white">
        <!-- Sidebar -->
        <?php include("sidebar.php") ?>

        <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

        <div id="main-content" class="h-full w-full relative overflow-y-auto lg:ml-64">
            <main class="calendar-container">
                <div class="calendar-header">
                    <h1 class="text-3xl font-bold gradient-text">Academic Calendar</h1>
                    <p class="text-gray-600 mt-2">View all academic events, holidays, exams, and assignments</p>
                </div>

                <!-- Event Type Filters -->
                <div class="filter-tabs">
                    <button class="filter-tab active-tab" onclick="filterEvents('all')">All Events</button>
                    <button class="filter-tab" onclick="filterEvents('exam')">Exams</button>
                    <button class="filter-tab" onclick="filterEvents('holiday')">Holidays</button>
                    <button class="filter-tab" onclick="filterEvents('assignment')">Assignments</button>
                </div>

                <!-- Calendar -->
                <div id="calendar"></div>

                <!-- Event Details Modal -->
                <div id="eventModal" class="event-modal">
                    <div class="modal-content animate-fade-in">
                        <button class="close-button" onclick="closeModal()">&times;</button>
                        <span id="modalEventType" class="event-badge"></span>
                        <h2 id="modalTitle" class="modal-title"></h2>
                        <p id="modalDate" class="modal-date"></p>
                        <p id="modalDescription" class="modal-description"></p>
                        <p id="modalSubject" class="modal-subject"></p>
                    </div>
                </div>
            </main>

            <?php include("../public/footer.php") ?>
        </div>
    </div>

    <!-- FullCalendar Scripts -->
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.4.0/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.4.0/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@4.4.0/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/list@4.4.0/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@4.4.0/main.min.js'></script>

    <!-- Events Data -->
    <script>
        const eventsData = <?php echo json_encode($events); ?>;
    </script>

    <!-- Custom Calendar Script -->
    <script src="js/calendar.js"></script>
</body>
</html>