<?php
session_start();
// Optionally, check if user is logged in
if (!isset($_SESSION['useremail'])) {
    header('Location: ../login/login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Course Materials - Student Panel</title>
    <!-- Add Tailwind CSS CDN to ensure it works -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f8fafc;
            font-family: 'Inter', sans-serif;
        }

        /* Container Styles */
        .materials-wrapper {
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            margin: 1rem;
        }

        /* Card Styles */
        .material-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .material-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-color: #93c5fd;
        }

        /* Icon Container */
        .icon-container {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        }

        /* Button Styles */
        .download-button {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .download-button:hover {
            transform: translateY(-2px);
        }

        /* Category Pills */
        .category-pill {
            display: inline-block;
            padding: 0.25rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .category-pill:hover {
            transform: translateY(-2px);
        }

        /* Search Input */
        .search-input {
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 0.5rem 1rem;
            padding-left: 2.5rem;
            width: 100%;
            max-width: 300px;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
    </style>
</head>
<body class="bg-gray-50">
    <?php include 'sidebar.php'; ?>

    <div class="ml-0 lg:ml-72 p-6">
        <!-- Header Section -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Course Materials</h1>
                <p class="text-gray-600 mt-1">Access and download your study materials</p>
            </div>
            
            <!-- Search Bar -->
            <div class="relative w-full md:w-auto">
                <input type="text" 
                    class="search-input"
                    placeholder="Search materials..."
                >
                <svg class="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
            </div>
        </div>

        <div class="materials-wrapper">
            <!-- Categories -->
            <div class="flex gap-3 mb-6 overflow-x-auto pb-2">
                <button class="category-pill bg-blue-100 text-blue-600">All Materials</button>
                <button class="category-pill bg-gray-100 text-gray-600">PDFs</button>
                <button class="category-pill bg-gray-100 text-gray-600">Presentations</button>
                <button class="category-pill bg-gray-100 text-gray-600">Documents</button>
            </div>

            <!-- Materials Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- PDF Material -->
                <div class="material-card">
                    <div class="icon-container bg-blue-50">
                        <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </div>
                    <span class="inline-block bg-blue-50 text-blue-600 text-xs px-2 py-1 rounded-full">PDF</span>
                    <h3 class="text-lg font-semibold mt-2">Introduction to Programming</h3>
                    <p class="text-gray-500 text-sm mt-1">Complete guide for beginners</p>
                    <div class="flex items-center justify-between mt-4">
                        <span class="text-sm text-gray-500">1.2 MB</span>
                        <a href="../uploads/materials/intro_programming.pdf" 
                           class="download-button bg-blue-500 text-white hover:bg-blue-600">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                            </svg>
                            Download
                        </a>
                    </div>
                </div>

                <!-- DOCX Material -->
                <div class="material-card">
                    <div class="icon-container bg-green-50">
                        <svg class="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </div>
                    <span class="inline-block bg-green-50 text-green-600 text-xs px-2 py-1 rounded-full">DOCX</span>
                    <h3 class="text-lg font-semibold mt-2">Data Structures Notes</h3>
                    <p class="text-gray-500 text-sm mt-1">Comprehensive study material</p>
                    <div class="flex items-center justify-between mt-4">
                        <span class="text-sm text-gray-500">800 KB</span>
                        <a href="../uploads/materials/data_structures.docx" 
                           class="download-button bg-green-500 text-white hover:bg-green-600">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                            </svg>
                            Download
                        </a>
                    </div>
                </div>

                <!-- PPT Material -->
                <div class="material-card">
                    <div class="icon-container bg-yellow-50">
                        <svg class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z"/>
                        </svg>
                    </div>
                    <span class="inline-block bg-yellow-50 text-yellow-600 text-xs px-2 py-1 rounded-full">PPTX</span>
                    <h3 class="text-lg font-semibold mt-2">Algorithms Slides</h3>
                    <p class="text-gray-500 text-sm mt-1">Lecture presentations</p>
                    <div class="flex items-center justify-between mt-4">
                        <span class="text-sm text-gray-500">2.5 MB</span>
                        <a href="../uploads/materials/algorithms_slides.pptx" 
                           class="download-button bg-yellow-500 text-white hover:bg-yellow-600">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                            </svg>
                            Download
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>