<?php
include("../includes/config.php");
include("../actions/checkstudent.php");

header('Content-Type: application/json');

$query = "UPDATE notifications SET read_status = 1 
          WHERE student_id = '{$_SESSION['userid']}'";

if (mysqli_query($db_conn, $query)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => mysqli_error($db_conn)]);
}
?>