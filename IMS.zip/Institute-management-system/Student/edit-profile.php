<?php include("../actions/checkstudent.php") ?>
<?php include("../public/header.php") ?>
<?php include("../includes/config.php") ?>

<?php
// Fetch current user data
$email = $_SESSION['useremail'];
$query = "SELECT u.*, s.*, d.name as department_name, y.year as academic_year, sec.name as section_name 
         FROM user u 
         JOIN student s ON u.id = s.id 
         JOIN department d ON s.departmentid = d.id 
         JOIN years y ON s.yearid = y.id 
         JOIN section sec ON s.sectionid = sec.id 
         WHERE u.email = '$email'";
$result = mysqli_query($db_conn, $query);
$user = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = mysqli_real_escape_string($db_conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($db_conn, $_POST['lastname']);
    $phone = mysqli_real_escape_string($db_conn, $_POST['phone']);
    $address = mysqli_real_escape_string($db_conn, $_POST['address']);
    $city = mysqli_real_escape_string($db_conn, $_POST['city']);
    $state = mysqli_real_escape_string($db_conn, $_POST['state']);
    
    // Handle password change
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $update_query = "UPDATE user SET 
                    firstname = '$firstname',
                    lastname = '$lastname',
                    phone = '$phone',
                    address = '$address',
                    city = '$city',
                    state = '$state'
                    WHERE email = '$email'";

    if (mysqli_query($db_conn, $update_query)) {
        // Handle password update if provided
        if (!empty($current_password) && !empty($new_password)) {
            if ($current_password === $user['password']) { // In production, use password_verify()
                if ($new_password === $confirm_password) {
                    $password_update = "UPDATE user SET password = '$new_password' WHERE email = '$email'";
                    mysqli_query($db_conn, $password_update);
                    $success_message = "Profile updated successfully with new password";
                } else {
                    $error_message = "New passwords do not match";
                }
            } else {
                $error_message = "Current password is incorrect";
            }
        } else {
            $success_message = "Profile updated successfully";
        }
        
        // Refresh user data
        $result = mysqli_query($db_conn, $query);
        $user = mysqli_fetch_assoc($result);
    } else {
        $error_message = "Error updating profile";
    }
}
?>

<style>
    .edit-profile-container {
        --primary: #0ea5e9;
        --secondary: #0284c7;
        --success: #22c55e;
        --danger: #ef4444;
        --warning: #f59e0b;
    }

    .form-section {
        transition: all 0.3s ease;
    }

    .form-section:hover {
        transform: translateY(-2px);
    }

    .profile-image-upload {
        position: relative;
        cursor: pointer;
    }

    .profile-image-upload::after {
        content: 'Change Photo';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.5);
        color: white;
        padding: 8px;
        font-size: 14px;
        text-align: center;
        border-radius: 0 0 100% 100%;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .profile-image-upload:hover::after {
        opacity: 1;
    }

    .input-group {
        position: relative;
        margin-bottom: 1.5rem;
    }

    .input-group label {
        position: absolute;
        left: 1rem;
        top: -0.5rem;
        background: white;
        padding: 0 0.5rem;
        font-size: 0.875rem;
        color: var(--primary);
        transition: all 0.3s ease;
    }

    .input-group input:focus ~ label,
    .input-group input:not(:placeholder-shown) ~ label {
        transform: translateY(-1.5rem);
        font-size: 0.75rem;
    }

    .success-alert, .error-alert {
        animation: slideIn 0.5s ease-out;
    }

    @keyframes slideIn {
        from { transform: translateY(-100%); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
</style>

<div class="flex overflow-hidden bg-white">
    <!-- Sidebar -->
    <?php include("sidebar.php") ?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main class="edit-profile-container py-10">
            <div class="container mx-auto px-4">
                <!-- Header -->
                <div class="mb-10 text-center">
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">Edit Profile</h1>
                    <p class="text-gray-600">Update your personal information</p>
                </div>

                <!-- Alerts -->
                <?php if (isset($success_message)): ?>
                    <div class="success-alert mb-6 bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="error-alert mb-6 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <!-- Edit Form -->
                <form method="POST" action="" enctype="multipart/form-data" class="max-w-4xl mx-auto">
                    <!-- Profile Image Section -->
                    <div class="form-section bg-white rounded-lg shadow-sm p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-6">Profile Picture</h2>
                        <div class="flex items-center justify-center">
                            <div class="profile-image-upload">
                                <img src="<?php echo $user['profile_image'] ?? 'https://img.freepik.com/free-icon/user_318-563642.jpg?w=360'; ?>" 
                                     alt="Profile" 
                                     class="w-32 h-32 rounded-full object-cover border-4 border-white shadow-lg">
                                <input type="file" name="profile_image" class="hidden" id="profile_image" accept="image/*">
                            </div>
                        </div>
                    </div>

                    <!-- Personal Information -->
                    <div class="form-section bg-white rounded-lg shadow-sm p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-6">Personal Information</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="input-group">
                                <input type="text" name="firstname" 
                                       value="<?php echo $user['firstname']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500"
                                       required>
                                <label>First Name</label>
                            </div>
                            <div class="input-group">
                                <input type="text" name="lastname" 
                                       value="<?php echo $user['lastname']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500"
                                       required>
                                <label>Last Name</label>
                            </div>
                            <div class="input-group">
                                <input type="tel" name="phone" 
                                       value="<?php echo $user['phone']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500"
                                       required>
                                <label>Phone Number</label>
                            </div>
                            <div class="input-group">
                                <input type="email" 
                                       value="<?php echo $user['email']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg bg-gray-100"
                                       disabled>
                                <label>Email (Cannot be changed)</label>
                            </div>
                        </div>
                    </div>

                    <!-- Address Information -->
                    <div class="form-section bg-white rounded-lg shadow-sm p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-6">Address Information</h2>
                        <div class="grid grid-cols-1 gap-6">
                            <div class="input-group">
                                <textarea name="address" 
                                          class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500"
                                          rows="3"><?php echo $user['address']; ?></textarea>
                                <label>Address</label>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="input-group">
                                    <input type="text" name="city" 
                                           value="<?php echo $user['city']; ?>" 
                                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                                    <label>City</label>
                                </div>
                                <div class="input-group">
                                    <input type="text" name="state" 
                                           value="<?php echo $user['state']; ?>" 
                                           class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                                    <label>State</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Change Password -->
                    <div class="form-section bg-white rounded-lg shadow-sm p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-6">Change Password</h2>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="input-group">
                                <input type="password" name="current_password" 
                                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                                <label>Current Password</label>
                            </div>
                            <div class="input-group">
                                <input type="password" name="new_password" 
                                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                                <label>New Password</label>
                            </div>
                            <div class="input-group">
                                <input type="password" name="confirm_password" 
                                       class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                                <label>Confirm New Password</label>
                            </div>
                        </div>
                    </div>

                    <!-- Academic Information (Read-only) -->
                    <div class="form-section bg-white rounded-lg shadow-sm p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-6">Academic Information</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <div class="input-group">
                                <input type="text" 
                                       value="<?php echo $user['department_name']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg bg-gray-100"
                                       disabled>
                                <label>Department</label>
                            </div>
                            <div class="input-group">
                                <input type="text" 
                                       value="<?php echo $user['academic_year']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg bg-gray-100"
                                       disabled>
                                <label>Year</label>
                            </div>
                            <div class="input-group">
                                <input type="text" 
                                       value="<?php echo $user['section_name']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg bg-gray-100"
                                       disabled>
                                <label>Section</label>
                            </div>
                            <div class="input-group">
                                <input type="text" 
                                       value="<?php echo $user['rollno']; ?>" 
                                       class="w-full px-4 py-2 border rounded-lg bg-gray-100"
                                       disabled>
                                <label>Roll Number</label>
                            </div>
                        </div>
                    </div>

                    <!-- Submit Buttons -->
                    <div class="flex justify-end space-x-4">
                        <a href="profile.php" 
                           class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition duration-300">
                            Cancel
                        </a>
                        <button type="submit" 
                                class="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300">
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Profile Image Upload
    const profileImage = document.querySelector('.profile-image-upload img');
    const profileInput = document.querySelector('#profile_image');

    profileImage.addEventListener('click', () => {
        profileInput.click();
    });

    profileInput.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profileImage.src = e.target.result;
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Form Validation
    const form = document.querySelector('form');
    form.addEventListener('submit', function(e) {
        const newPassword = document.querySelector('input[name="new_password"]').value;
        const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
        const currentPassword = document.querySelector('input[name="current_password"]').value;

        if (newPassword || confirmPassword || currentPassword) {
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('New passwords do not match!');
                return;
            }
            if (!currentPassword) {
                e.preventDefault();
                alert('Please enter your current password to change password!');
                return;
            }
        }
    });

    // Animation for form sections
    const sections = document.querySelectorAll('.form-section');
    sections.forEach((section, index) => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        setTimeout(() => {
            section.style.transition = 'all 0.5s ease';
            section.style.opacity = '1';
            section.style.transform = 'translateY(0)';
        }, 100 * index);
    });
});
</script>

<?php include("../public/footer.php") ?>