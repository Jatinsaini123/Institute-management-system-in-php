<?php
include("../includes/config.php");
include("../actions/checkstudent.php");

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$notification_id = $data['notification_id'];
$action = $data['action'];

$read_status = $action === 'read' ? 1 : 0;

$query = "UPDATE notifications SET read_status = $read_status 
          WHERE id = '$notification_id' AND student_id = '{$_SESSION['userid']}'";

if (mysqli_query($db_conn, $query)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => mysqli_error($db_conn)]);
}
?>