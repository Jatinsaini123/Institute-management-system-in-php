<style>
/* Scrollbar Styles */
.sidebar-scroll {
    height: calc(100vh - 260px);
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #3b82f6 transparent;
}

.sidebar-scroll::-webkit-scrollbar {
    width: 4px;
}

.sidebar-scroll::-webkit-scrollbar-track {
    background: transparent;
}

.sidebar-scroll::-webkit-scrollbar-thumb {
    background-color: #3b82f6;
    border-radius: 10px;
}

.sidebar-scroll::-webkit-scrollbar-thumb:hover {
    background-color: #2563eb;
}

/* Main Styles */
.sidebar-container {
    --primary: #3b82f6;
    --hover: #2563eb;
    --text-primary: #1e293b;
    --bg-hover: #f1f5f9;
}

.nav-link {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    border-radius: 0.5rem;
    transition: all 0.2s ease;
    margin-bottom: 0.5rem;
}

.nav-link:hover {
    background-color: var(--bg-hover);
    transform: translateX(3px);
}

.nav-link.active {
    background: linear-gradient(to right, #3b82f6, #2563eb);
    color: white;
    box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.2);
}

.profile-card {
    background: linear-gradient(to right, #f0f9ff, #e0f2fe);
    border-radius: 1rem;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
}

.notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ef4444;
    color: white;
    border-radius: 50%;
    padding: 1px 5px;
    font-size: 0.7rem;
    font-weight: bold;
}

.logout-btn {
    background: linear-gradient(to right, #f9fafb, #f3f4f6);
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    padding: 0.75rem;
    transition: all 0.2s ease;
}

.logout-btn:hover {
    background: #fee2e2;
    color: #ef4444;
}
</style>

<aside id="sidebar" class="fixed z-20 h-full top-0 left-0 pt-4 flex lg:flex w-72 flex-col shadow-md bg-white transition-transform duration-300 ease-in-out transform -translate-x-full lg:translate-x-0" aria-label="Sidebar">
    <!-- Logo Section -->
    <div class="px-6 pb-6 flex justify-center border-b">
        <a href="index.php" class="flex items-center">
            <img src="../assets/images/logo.png" class="h-10" alt="IMS logo"/>
        </a>
    </div>

    <!-- Profile Section -->
    <div class="px-6 py-4">
        <div class="profile-card">
            <div class="flex items-center">
                <div class="relative">
                    <img src="https://img.freepik.com/free-icon/user_318-563642.jpg?w=360" alt="Profile" 
                        class="w-14 h-14 rounded-full border-2 border-blue-500 p-0.5"/>
                    <span class="absolute bottom-0 right-0 bg-green-500 w-3 h-3 rounded-full border-2 border-white"></span>
                </div>
                <div class="ml-3">
                    <h5 class="font-semibold text-gray-800">Student Panel</h5>
                    <p class="text-sm text-gray-500"><?php echo $_SESSION['useremail'] ?? ''; ?></p>
                </div>
            </div>
            
            <div class="flex mt-4 space-x-2">
                <a href="profile.php" class="text-xs px-3 py-1.5 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100">
                    Profile
                </a>
                <a href="edit-profile.php" class="text-xs px-3 py-1.5 bg-gray-50 text-gray-600 rounded-md hover:bg-gray-100">
                    Settings
                </a>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <div class="sidebar-scroll px-6">
        <h6 class="text-xs font-medium text-gray-400 uppercase tracking-wider mb-4">Main Menu</h6>
        <nav>
            <a href="index.php" class="nav-link active">
                <svg class="w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                </svg>
                <span>Dashboard</span>
            </a>
            
            <a href="attendance.php" class="nav-link">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                </svg>
                <span>My Attendance</span>
            </a>
            
            <a href="grading.php" class="nav-link">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                </svg>
                <span>My Marks</span>
            </a>
            
            <a href="notifications.php" class="nav-link">
                <div class="relative">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                    </svg>
                    <span class="notification-badge">3</span>
                </div>
                <span>Notifications</span>
            </a>
            
            <a href="materials.php" class="nav-link">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                </svg>
                <span>Course Materials</span>
            </a>
        </nav>
    </div>
    
    <!-- Footer -->
    <div class="mt-auto px-6 py-4 border-t">
        <form action="../login/login.php" method="post">
            <button type="submit" class="logout-btn w-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                <span>Sign Out</span>
            </button>
        </form>
    </div>
</aside>