<?php include("../actions/checkstudent.php") ?>
<?php include("../public/header.php") ?>
<?php include("../includes/config.php") ?>

<style>
    .notifications-container {
        --primary: #0ea5e9;
        --secondary: #0284c7;
        --success: #22c55e;
        --warning: #f59e0b;
        --danger: #ef4444;
        --gray-light: #f3f4f6;
    }

    .notification-item {
        transition: all 0.3s ease;
        animation: slideIn 0.5s ease-out;
    }

    .notification-item:hover {
        transform: translateX(5px);
    }

    .notification-item.unread {
        background-color: rgba(14, 165, 233, 0.05);
    }

    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }

    .filter-button.active {
        background-color: var(--primary);
        color: white;
    }

    .notification-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
    }

    .icon-academic { background-color: rgba(14, 165, 233, 0.1); color: var(--primary); }
    .icon-attendance { background-color: rgba(34, 197, 94, 0.1); color: var(--success); }
    .icon-exam { background-color: rgba(245, 158, 11, 0.1); color: var(--warning); }
    .icon-alert { background-color: rgba(239, 68, 68, 0.1); color: var(--danger); }
</style>

<?php
// Function to get time ago
function time_elapsed_string($datetime) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->d == 0) {
        if ($diff->h == 0) {
            if ($diff->i == 0) {
                return "just now";
            }
            return $diff->i . " minute" . ($diff->i > 1 ? "s" : "") . " ago";
        }
        return $diff->h . " hour" . ($diff->h > 1 ? "s" : "") . " ago";
    }
    if ($diff->d < 7) {
        return $diff->d . " day" . ($diff->d > 1 ? "s" : "") . " ago";
    }
    return date('M j, Y', strtotime($datetime));
}

$student_id = $userrow->id;
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

$notifications_query = "SELECT n.*, 
                              CASE 
                                WHEN n.type = 'academic' THEN 'Academic'
                                WHEN n.type = 'attendance' THEN 'Attendance'
                                WHEN n.type = 'exam' THEN 'Exam'
                                ELSE 'Alert'
                              END as type_label
                       FROM notifications n
                       WHERE n.student_id = '$student_id'";

if ($filter !== 'all') {
    $notifications_query .= " AND n.type = '$filter'";
}

$notifications_query .= " ORDER BY n.created_at DESC";
$notifications_result = mysqli_query($db_conn, $notifications_query);

function addSampleNotifications($student_id, $db_conn) {
    $notifications = [
        [
            'type' => 'academic',
            'title' => 'New Course Material Available',
            'message' => 'The course material for Database Management System has been updated. Check it out!',
            'action_url' => '/student/courses.php'
        ],
        [
            'type' => 'academic',
            'title' => 'Assignment Submission Reminder',
            'message' => 'Don\'t forget to submit your Java Programming assignment by tomorrow.',
            'action_url' => '/student/assignments.php'
        ],
        [
            'type' => 'attendance',
            'title' => 'Low Attendance Alert',
            'message' => 'Your attendance in Computer Networks is below 75%. Please maintain regular attendance.',
            'action_url' => '/student/attendance.php'
        ],
        [
            'type' => 'attendance',
            'title' => 'Attendance Updated',
            'message' => 'Your attendance has been marked for today\'s Data Structures class.',
            'action_url' => '/student/attendance.php'
        ],
        [
            'type' => 'exam',
            'title' => 'Upcoming CAT-1 Exam',
            'message' => 'CAT-1 examination for all subjects will begin from next week. Check the schedule.',
            'action_url' => '/student/exams.php'
        ],
        [
            'type' => 'exam',
            'title' => 'Results Published',
            'message' => 'Your CAT-2 results have been published. View your marks now.',
            'action_url' => '/student/results.php'
        ],
        [
            'type' => 'alert',
            'title' => 'Important Notice',
            'message' => 'All classes will be conducted online tomorrow due to heavy rain forecast.',
            'action_url' => null
        ],
        [
            'type' => 'alert',
            'title' => 'Fee Payment Reminder',
            'message' => 'Last date for paying semester fees is approaching. Please clear your dues.',
            'action_url' => '/student/fees.php'
        ]
    ];

    foreach ($notifications as $notification) {
        $query = "INSERT INTO notifications (student_id, type, title, message, action_url) 
                 VALUES ('$student_id', 
                         '{$notification['type']}', 
                         '{$notification['title']}', 
                         '{$notification['message']}', 
                         " . ($notification['action_url'] ? "'{$notification['action_url']}'" : "NULL") . ")";
        mysqli_query($db_conn, $query);
    }
}

// Usage example:
// addSampleNotifications($student_id, $db_conn);
?>

<div class="flex overflow-hidden bg-white">
    <!-- Sidebar -->
    <?php include("sidebar.php") ?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main class="notifications-container py-10">
            <!-- Changed container width and added max-width -->
            <div class="max-w-4xl mx-auto px-4">
                <!-- Header -->
                <div class="flex justify-between items-center mb-8">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800">Notifications</h1>
                        <p class="text-gray-600 mt-1">Stay updated with your academic activities</p>
                    </div>
                    <button id="markAllRead" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300">
                        Mark All as Read
                    </button>
                </div>

                <!-- Filters -->
                <div class="mb-6 flex flex-wrap gap-2">
                    <button class="filter-button px-4 py-2 rounded-full border <?php echo $filter === 'all' ? 'active' : ''; ?>"
                            data-filter="all">
                        All
                    </button>
                    <button class="filter-button px-4 py-2 rounded-full border <?php echo $filter === 'academic' ? 'active' : ''; ?>"
                            data-filter="academic">
                        Academic
                    </button>
                    <button class="filter-button px-4 py-2 rounded-full border <?php echo $filter === 'attendance' ? 'active' : ''; ?>"
                            data-filter="attendance">
                        Attendance
                    </button>
                    <button class="filter-button px-4 py-2 rounded-full border <?php echo $filter === 'exam' ? 'active' : ''; ?>"
                            data-filter="exam">
                        Exam
                    </button>
                    <button class="filter-button px-4 py-2 rounded-full border <?php echo $filter === 'alert' ? 'active' : ''; ?>"
                            data-filter="alert">
                        Alerts
                    </button>
                </div>

                <!-- Notifications List with shadow and rounded corners -->
                <div class="bg-white rounded-lg shadow-sm border">
                    <?php if (mysqli_num_rows($notifications_result) > 0): ?>
                        <?php while ($notification = mysqli_fetch_assoc($notifications_result)): ?>
                            <div class="notification-item p-4 border-b last:border-b-0 flex items-start gap-4 <?php echo $notification['read_status'] ? '' : 'unread'; ?>"
                                 data-id="<?php echo $notification['id']; ?>">
                                <!-- Icon -->
                                <div class="notification-icon icon-<?php echo strtolower($notification['type']); ?>">
                                    <?php if ($notification['type'] === 'academic'): ?>
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                  d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                        </svg>
                                    <?php elseif ($notification['type'] === 'attendance'): ?>
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                                        </svg>
                                    <?php elseif ($notification['type'] === 'exam'): ?>
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                        </svg>
                                    <?php else: ?>
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                                        </svg>
                                    <?php endif; ?>
                                </div>

                                <!-- Content -->
                                <div class="flex-1">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <h3 class="font-semibold text-gray-800">
                                                <?php echo htmlspecialchars($notification['title']); ?>
                                            </h3>
                                            <p class="text-gray-600 mt-1">
                                                <?php echo htmlspecialchars($notification['message']); ?>
                                            </p>
                                        </div>
                                        <span class="text-sm text-gray-500">
                                            <?php echo time_elapsed_string($notification['created_at']); ?>
                                        </span>
                                    </div>
                                    
                                    <!-- Action Buttons -->
                                    <div class="mt-3 flex items-center gap-4">
                                        <?php if ($notification['action_url']): ?>
                                            <a href="<?php echo htmlspecialchars($notification['action_url']); ?>" 
                                               class="text-blue-500 hover:text-blue-600 text-sm font-medium">
                                                View Details
                                            </a>
                                        <?php endif; ?>
                                        <button class="mark-read text-gray-500 hover:text-gray-700 text-sm"
                                                data-id="<?php echo $notification['id']; ?>">
                                            <?php echo $notification['read_status'] ? 'Mark as Unread' : 'Mark as Read'; ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="p-8 text-center">
                            <svg class="w-16 h-16 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
                            </svg>
                            <h3 class="mt-4 text-lg font-medium text-gray-900">No notifications</h3>
                            <p class="mt-1 text-gray-500">You're all caught up! Check back later for new updates.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filter Buttons
    const filterButtons = document.querySelectorAll('.filter-button');
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            window.location.href = `notifications.php?filter=${filter}`;
        });
    });

    // Mark as Read/Unread
    const markReadButtons = document.querySelectorAll('.mark-read');
    markReadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const notificationId = this.dataset.id;
            const notificationItem = this.closest('.notification-item');
            
            // Send AJAX request to mark notification
            fetch('../actions/mark_notification.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    notification_id: notificationId,
                    action: notificationItem.classList.contains('unread') ? 'read' : 'unread'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    notificationItem.classList.toggle('unread');
                    this.textContent = notificationItem.classList.contains('unread') ? 
                        'Mark as Read' : 'Mark as Unread';
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    });

    // Mark All as Read
    const markAllReadButton = document.getElementById('markAllRead');
    if (markAllReadButton) {
        markAllReadButton.addEventListener('click', function() {
            fetch('../actions/mark_all_notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelectorAll('.notification-item.unread').forEach(item => {
                        item.classList.remove('unread');
                        item.querySelector('.mark-read').textContent = 'Mark as Unread';
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    }

    // Add animation delay for notifications
    const notifications = document.querySelectorAll('.notification-item');
    notifications.forEach((notification, index) => {
        notification.style.animationDelay = `${index * 0.1}s`;
    });
});
</script>

<?php include("../public/footer.php") ?>