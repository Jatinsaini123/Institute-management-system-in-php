<?php include("../actions/checkstudent.php") ?>
<?php include("../public/header.php") ?>
<?php include("../includes/config.php") ?>

<style>
    /* Profile Page Specific Styles */
    .profile-container {
        --primary: #0ea5e9;
        --secondary: #0284c7;
        --success: #22c55e;
        --warning: #f59e0b;
        --danger: #ef4444;
    }

    .profile-header {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        height: 200px; /* Increased from 150px */
        border-radius: 0 0 2rem 2rem; /* Increased from 1.5rem */
        position: relative;
        padding: 2rem; /* Added padding */
    }

    .profile-avatar {
        position: relative;
        margin-top: -75px; /* Increased from -50px */
        border: 4px solid white; /* Increased from 3px */
        border-radius: 50%;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .status-badge {
        position: absolute;
        bottom: 5px;
        right: 5px;
        width: 20px; /* Increased from 16px */
        height: 20px; /* Increased from 16px */
        border-radius: 50%;
        background: var(--success);
        border: 3px solid white; /* Increased from 2px */
    }

    .info-card {
        transition: all 0.3s ease;
        padding: 2rem; /* Increased from 1rem */
        margin: 1rem; /* Added margin */
    }

    .info-card:hover {
        transform: translateY(-5px); /* Increased from -3px */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .achievement-badge {
        position: relative;
        overflow: hidden;
        padding: 1.7rem; /* Added padding */
        margin: 1rem 0; /* Added margin */
    }

    .achievement-badge::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(45deg, transparent, rgba(255,255,255,0.2), transparent);
        transform: translateX(-100%);
        animation: shine 3s infinite;
    }

    /* Added new spacing classes */
    .content-padding {
        padding: 2rem;
    }

    .section-margin {
        margin: 2rem 0;
    }

    .card-spacing {
        gap: 2rem;
        margin: 2rem;
    }

    .inner-padding {
        padding: 1.5rem;
    }

    .header-margin {
        margin-bottom: 2rem;
    }

    .text-spacing {
        margin: 1rem 0;
        line-height: 1.8;
    }

    @keyframes shine {
        100% { transform: translateX(100%); }
    }
</style>

<div class="flex overflow-hidden bg-white">
    <!-- Sidebar -->
    <?php include("sidebar.php") ?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main class="profile-container">
            <!-- Profile Header -->
            <div class="profile-header flex items-center justify-center">
                <div class="text-white text-center">
                    <h1 class="text-2xl font-bold mb-1">Student Profile</h1>
                    <p class="text-gray-100 text-sm">Manage your academic information</p>
                </div>
            </div>

            <?php
            // Fetch student details
            $email = $_SESSION['useremail'];
            $query = "SELECT u.*, s.*, d.name as department_name, y.year as academic_year, sec.name as section_name 
                     FROM user u 
                     JOIN student s ON u.id = s.id 
                     JOIN department d ON s.departmentid = d.id 
                     JOIN years y ON s.yearid = y.id 
                     JOIN section sec ON s.sectionid = sec.id 
                     WHERE u.email = '$email'";
            $result = mysqli_query($db_conn, $query);
            $student = mysqli_fetch_assoc($result);
            ?>

            <!-- Profile Content -->
            <div class="container mx-auto px-3 py-4"> <!-- Reduced padding -->
                <!-- Basic Info Card -->
                <div class="flex flex-col items-center">
                    <div class="profile-avatar">
                        <img src="https://img.freepik.com/free-icon/user_318-563642.jpg?w=360" 
                             alt="Profile" 
                             class="w-24 h-24 rounded-full object-cover"> <!-- Reduced size -->
                        <div class="status-badge"></div>
                    </div>
                    <h2 class="text-xl font-bold mt-3"><?php echo $student['firstname'] . ' ' . $student['lastname']; ?></h2>
                    <p class="text-gray-600 text-sm">Student ID: <?php echo $student['id']; ?></p>
                </div>

                <!-- Information Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4"> <!-- Reduced gap and margin -->
                    <!-- Academic Information -->
                    <div class="info-card bg-white rounded-lg shadow-sm">
                        <h3 class="text-base font-semibold mb-3 text-gray-800">Academic Information</h3>
                        <div class="space-y-2"> <!-- Reduced spacing -->
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Department</span>
                                <span class="font-medium"><?php echo $student['department_name']; ?></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Year</span>
                                <span class="font-medium"><?php echo $student['academic_year']; ?></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Section</span>
                                <span class="font-medium"><?php echo $student['section_name']; ?></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Roll Number</span>
                                <span class="font-medium"><?php echo $student['rollno']; ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Information -->
                    <div class="info-card bg-white rounded-lg shadow-sm">
                        <h3 class="text-base font-semibold mb-3 text-gray-800">Contact Information</h3>
                        <div class="space-y-2"> <!-- Reduced spacing -->
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Email</span>
                                <span class="font-medium"><?php echo $student['email']; ?></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Phone</span>
                                <span class="font-medium"><?php echo $student['phone']; ?></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Address</span>
                                <span class="font-medium"><?php echo $student['address'] ?? 'Not provided'; ?></span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">City</span>
                                <span class="font-medium"><?php echo $student['city'] ?? 'Not provided'; ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Attendance Overview -->
                    <div class="info-card bg-white rounded-lg shadow-sm">
                        <h3 class="text-base font-semibold mb-3 text-gray-800">Attendance Overview</h3>
                        <?php
                        // Fetch attendance statistics
                        $attendance_query = "SELECT 
                            COUNT(CASE WHEN Status = 'P' THEN 1 END) as present,
                            COUNT(CASE WHEN Status = 'A' THEN 1 END) as absent
                            FROM attendance 
                            WHERE studentid = '{$student['id']}'";
                        $attendance_result = mysqli_query($db_conn, $attendance_query);
                        $attendance = mysqli_fetch_assoc($attendance_result);
                        
                        $total_classes = $attendance['present'] + $attendance['absent'];
                        $attendance_percentage = $total_classes > 0 ? 
                            round(($attendance['present'] / $total_classes) * 100, 2) : 0;
                        ?>
                        <div class="space-y-3"> <!-- Reduced spacing -->
                            <div class="relative pt-1">
                                <div class="flex mb-2 items-center justify-between">
                                    <div>
                                        <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-primary bg-blue-200">
                                            Attendance
                                        </span>
                                    </div>
                                    <div class="text-right">
                                        <span class="text-xs font-semibold inline-block text-primary">
                                            <?php echo $attendance_percentage; ?>%
                                        </span>
                                    </div>
                                </div>
                                <div class="overflow-hidden h-1.5 mb-3 text-xs flex rounded bg-blue-200"> <!-- Reduced height -->
                                    <div style="width:<?php echo $attendance_percentage; ?>%" 
                                         class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500">
                                    </div>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3 text-center"> <!-- Reduced gap -->
                                <div class="bg-green-100 p-2 rounded-lg"> <!-- Reduced padding -->
                                    <div class="font-bold text-green-600 text-sm"><?php echo $attendance['present']; ?></div>
                                    <div class="text-xs text-green-800">Present</div>
                                </div>
                                <div class="bg-red-100 p-2 rounded-lg"> <!-- Reduced padding -->
                                    <div class="font-bold text-red-600 text-sm"><?php echo $attendance['absent']; ?></div>
                                    <div class="text-xs text-red-800">Absent</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Academic Performance -->
                <div class="mt-4"> <!-- Reduced margin -->
                    <div class="bg-white p-4 rounded-lg shadow-sm"> <!-- Reduced padding -->
                        <h3 class="text-base font-semibold mb-3 text-gray-800">Academic Performance</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full table-auto">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Exam</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Marks</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php while($mark = mysqli_fetch_assoc($marks_result)): ?>
                                    <tr class="text-sm">
                                        <td class="px-4 py-2"><?php echo $mark['subject']; ?></td>
                                        <td class="px-4 py-2"><?php echo $mark['examname']; ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo $mark['mark'] . '/' . $mark['totalmarks']; ?>
                                        </td>
                                        <td class="px-4 py-2">
                                            <?php 
                                            $percentage = ($mark['mark'] / $mark['totalmarks']) * 100;
                                            echo round($percentage, 2) . '%';
                                            ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Edit Profile Button -->
                <div class="mt-4 flex justify-center"> <!-- Reduced margin -->
                    <a href="edit-profile.php" 
                       class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg 
                              text-sm transition duration-300 ease-in-out transform hover:-translate-y-1">
                        Edit Profile
                    </a>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Animation for cards
    const cards = document.querySelectorAll('.info-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Add loading animation
    const mainContent = document.getElementById('main-content');
    mainContent.style.opacity = '0';
    setTimeout(() => {
        mainContent.style.transition = 'opacity 0.3s ease-in-out';
        mainContent.style.opacity = '1';
    }, 100);
});
</script>

<?php include("../public/footer.php") ?>