<?php
session_start();
include('../includes/config.php');

// Check if user is logged in
if (!isset($_SESSION['useremail'])) {
    header("Location: ../Login/login.php");
    exit();
}

$email = $_SESSION['useremail'];
$query = "SELECT * FROM fees WHERE student_email = '$email'";
$result = mysqli_query($db_conn, $query);

// Get fee summary
$total_query = "SELECT 
    SUM(amount) as total_fees,
    SUM(CASE WHEN status = 'Paid' THEN amount ELSE 0 END) as paid_amount
    FROM fees WHERE student_email = '$email'";
$total_result = mysqli_query($db_conn, $total_query);
$totals = mysqli_fetch_assoc($total_result);
$pending_amount = $totals['total_fees'] - $totals['paid_amount'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Fees</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="flex">
        <?php include('sidebar.php'); ?>

        <div class="flex-1 ml-64">
            <!-- Top Navigation Bar -->
            <nav class="bg-white shadow-md p-3 fixed top-0 right-0 left-64 z-10">
                <div class="flex justify-between items-center">
                    <h1 class="text-xl font-bold text-gray-800">Fee Management</h1>
                    <div class="flex items-center space-x-3">
                        <span class="text-sm text-gray-600">
                            <i class="fas fa-user-circle mr-2"></i>
                            <?php echo $_SESSION['useremail']; ?>
                        </span>
                    </div>
                </div>
            </nav>

            <!-- Main Content -->
            <div class="pt-16 p-4">
                <!-- Fee Summary Cards -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div class="bg-white rounded-lg shadow-sm p-4 border-l-4 border-blue-500">
                        <div class="flex items-center">
                            <div class="p-2 rounded-full bg-blue-50 mr-3">
                                <i class="fas fa-money-bill text-blue-500 text-lg"></i>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Total Fees</p>
                                <p class="text-lg font-bold text-gray-800">₹<?php echo number_format($totals['total_fees'], 2); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-sm p-4 border-l-4 border-green-500">
                        <div class="flex items-center">
                            <div class="p-2 rounded-full bg-green-50 mr-3">
                                <i class="fas fa-check-circle text-green-500 text-lg"></i>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Paid Amount</p>
                                <p class="text-lg font-bold text-green-600">₹<?php echo number_format($totals['paid_amount'], 2); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow-sm p-4 border-l-4 border-red-500">
                        <div class="flex items-center">
                            <div class="p-2 rounded-full bg-red-50 mr-3">
                                <i class="fas fa-clock text-red-500 text-lg"></i>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Pending Amount</p>
                                <p class="text-lg font-bold text-red-600">₹<?php echo number_format($pending_amount, 2); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Fee Details Table -->
                <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="p-3 border-b">
                        <h2 class="text-lg font-semibold text-gray-800">Fee Payment History</h2>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sr No.</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Semester</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Due Date</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php
                                if (mysqli_num_rows($result) > 0) {
                                    $i = 1;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $status = $row['status'];
                                ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo $i++; ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-800"><?php echo $row['semester']; ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-800">₹<?php echo number_format($row['amount'], 2); ?></td>
                                        <td class="px-4 py-3 text-sm text-gray-800">
                                            <i class="far fa-calendar-alt mr-1 text-gray-400"></i>
                                            <?php echo date('d M Y', strtotime($row['due_date'])); ?>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="px-2 py-1 text-xs font-semibold rounded-full inline-flex items-center
                                                <?php echo $status == 'Paid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                                <i class="fas <?php echo $status == 'Paid' ? 'fa-check-circle' : 'fa-clock'; ?> mr-1"></i>
                                                <?php echo $status; ?>
                                            </span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <?php if ($status != 'Paid'): ?>
                                                <button onclick="openPayModal(<?php echo $row['id']; ?>, <?php echo $row['amount']; ?>)"
                                                        class="inline-flex items-center px-3 py-1 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded">
                                                    <i class="fas fa-credit-card mr-1"></i>
                                                    Pay Now
                                                </button>
                                            <?php else: ?>
                                                <span class="text-gray-400">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php
                                    }
                                } else {
                                    echo "<tr><td colspan='6' class='px-4 py-3 text-center text-gray-500'>No fee records found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-lg bg-white">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-bold text-gray-900">Make Payment</h3>
                <button onclick="closePayModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="paymentForm" action="process_payment.php" method="POST">
                <input type="hidden" id="fee_id" name="fee_id">
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2">Amount to Pay</label>
                    <div class="relative">
                        <span class="absolute left-3 top-2 text-gray-600">₹</span>
                        <input type="text" id="amount" readonly 
                               class="w-full pl-8 p-2 border rounded-lg bg-gray-50">
                    </div>
                </div>
                <div class="flex justify-end gap-3">
                    <button type="button" onclick="closePayModal()" 
                            class="px-3 py-2 text-gray-600 hover:text-gray-800 font-medium">
                        Cancel
                    </button>
                    <button type="submit" 
                            class="px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                        <i class="fas fa-lock mr-1"></i>
                        Proceed to Pay
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openPayModal(feeId, amount) {
            document.getElementById('fee_id').value = feeId;
            document.getElementById('amount').value = amount.toFixed(2);
            document.getElementById('paymentModal').classList.remove('hidden');
        }

        function closePayModal() {
            document.getElementById('paymentModal').classList.add('hidden');
        }
    </script>
</body>
</html>
