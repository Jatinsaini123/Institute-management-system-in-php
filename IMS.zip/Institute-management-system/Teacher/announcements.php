<?php include("../public/header.php") ?>

<div class="flex overflow-hidden bg-white pt-16">

<!-- Sidebar -->
<?php include("sidebar.php") ?>

<div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

<div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
  <main>
    <div class="pt-6 px-4">
      <div class="w-full grid grid-cols-1 xl:grid-cols-1 2xl:grid-cols-1 gap-4 content-center max-w-4xl mx-auto">
        
        <div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8">
          <div class="mb-4 flex items-center justify-between">
            <div>
              <h3 class="text-xl font-bold text-gray-900 mb-2">Announcements</h3>
              <p class="text-sm text-gray-600">Create and manage announcements for your classes</p>
            </div>
          </div>

          <!-- Create Announcement Form -->
          <div class="mt-4">
            <form action="process_announcement.php" method="POST" class="space-y-4">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
                  <select name="class_id" required class="w-full border border-gray-300 rounded-md p-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="">Choose a class</option>
                    <option value="all">All Classes</option>
                    <?php foreach($classes as $class): ?>
                        <option value="<?php echo htmlspecialchars($class['class_id']); ?>">
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                  </select>
                </div>

                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Priority Level</label>
                  <select name="priority" required class="w-full border border-gray-300 rounded-md p-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="normal">Normal</option>
                    <option value="important">Important</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Title</label>
                <input type="text" name="title" required 
                  class="w-full border border-gray-300 rounded-md p-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter announcement title">
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Message</label>
                <textarea name="message" rows="4" required
                  class="w-full border border-gray-300 rounded-md p-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter your announcement message"></textarea>
              </div>

              <div class="flex justify-end">
                <button type="submit" 
                  class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                  Post Announcement
                </button>
              </div>
            </form>
          </div>

          <!-- Add this right after the form section -->
          <?php if (isset($_SESSION['success_message'])): ?>
              <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                  <?php 
                  echo $_SESSION['success_message'];
                  unset($_SESSION['success_message']);
                  ?>
              </div>
          <?php endif; ?>

          <?php if (isset($_SESSION['error_message'])): ?>
              <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                  <?php 
                  echo $_SESSION['error_message'];
                  unset($_SESSION['error_message']);
                  ?>
              </div>
          <?php endif; ?>

          <!-- Announcements List -->
          <div class="mt-8">
            <h4 class="text-lg font-semibold text-gray-800 mb-4">Recent Announcements</h4>
            <div class="space-y-4">
              <?php
              // Get teacher's classes
              $teacher_email = $_SESSION['teacheremail'];
              $class_query = "SELECT class_id, class_name FROM classes WHERE teacher_email = ?";
              $stmt = $db_conn->prepare($class_query);
              $stmt->bind_param("s", $teacher_email);
              $stmt->execute();
              $classes_result = $stmt->get_result();
              
              $classes = [];
              while ($row = $classes_result->fetch_assoc()) {
                  $classes[] = $row;
              }

              // Get announcements
              $query = "SELECT a.*, c.class_name 
                       FROM announcements a 
                       LEFT JOIN classes c ON a.class_id = c.class_id 
                       WHERE a.teacher_email = ? 
                       ORDER BY a.created_at DESC";
              
              $stmt = $db_conn->prepare($query);
              $stmt->bind_param("s", $teacher_email);
              $stmt->execute();
              $result = $stmt->get_result();
              
              if ($result->num_rows === 0) {
                  echo '<p class="text-gray-500 text-center py-4">No announcements yet</p>';
              }

              while ($announcement = $result->fetch_assoc()) {
                  $priorityColor = [
                      'normal' => 'bg-blue-100 text-blue-800',
                      'important' => 'bg-yellow-100 text-yellow-800',
                      'urgent' => 'bg-red-100 text-red-800'
                  ][$announcement['priority']] ?? 'bg-gray-100 text-gray-800';
              ?>
                <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div class="flex justify-between items-start mb-2">
                    <div>
                      <h5 class="font-semibold text-gray-900"><?php echo htmlspecialchars($announcement['title']); ?></h5>
                      <p class="text-sm text-gray-500">
                        Posted to: <?php echo htmlspecialchars($announcement['class_name']); ?> • 
                        <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?>
                      </p>
                    </div>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo $priorityColor; ?>">
                      <?php echo ucfirst($announcement['priority']); ?>
                    </span>
                  </div>
                  <p class="text-gray-600 mb-3"><?php echo nl2br(htmlspecialchars($announcement['message'])); ?></p>
                  <div class="flex justify-end space-x-2">
                    <button onclick="editAnnouncement(<?php echo $announcement['id']; ?>)"
                      class="text-sm text-blue-600 hover:text-blue-800">Edit</button>
                    <button onclick="deleteAnnouncement(<?php echo $announcement['id']; ?>)"
                      class="text-sm text-red-600 hover:text-red-800">Delete</button>
                  </div>
                </div>
              <?php } ?>
            </div>
          </div>

        </div>
      </div>
    </div>
  </main>

  <!-- Delete Confirmation Modal -->
  <div id="deleteModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
      <div class="mt-3 text-center">
        <h3 class="text-lg leading-6 font-medium text-gray-900">Delete Announcement</h3>
        <div class="mt-2 px-7 py-3">
          <p class="text-sm text-gray-500">Are you sure you want to delete this announcement? This action cannot be undone.</p>
        </div>
        <div class="items-center px-4 py-3">
          <button id="deleteConfirm" class="px-4 py-2 bg-red-600 text-white text-base font-medium rounded-md shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500">
            Delete
          </button>
          <button onclick="closeDeleteModal()" class="ml-2 px-4 py-2 bg-gray-100 text-gray-700 text-base font-medium rounded-md shadow-sm hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500">
            Cancel
          </button>
        </div>
      </div>
    </div>
  </div>

<?php include("../public/footer.php") ?>

<script>
function editAnnouncement(id) {
  // Implement edit functionality
  window.location.href = `edit_announcement.php?id=${id}`;
}

function deleteAnnouncement(id) {
  const modal = document.getElementById('deleteModal');
  const deleteBtn = document.getElementById('deleteConfirm');
  
  modal.classList.remove('hidden');
  deleteBtn.onclick = () => {
    window.location.href = `delete_announcement.php?id=${id}`;
  };
}

function closeDeleteModal() {
  document.getElementById('deleteModal').classList.add('hidden');
}
</script>
