<?php 
include("../actions/checkteacher.php");
include("../public/header.php");
include("../includes/config.php");
?>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="py-8 px-6">
                <div class="max-w-6xl mx-auto">
                    <!-- Header Section -->
                    <div class="mb-6">
                        <h1 class="text-2xl font-bold text-gray-900 mb-2">Academic Calendar</h1>
                        <p class="text-sm text-gray-600">Manage your schedule, classes, and important events</p>
                    </div>

                    <!-- Main Content Area -->
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        <!-- Calendar Sidebar - Left Side -->
                        <div class="lg:col-span-3">
                            <div class="bg-white shadow rounded-xl overflow-hidden">
                                <!-- Current Month Mini Calendar -->
                                <div class="p-4 border-b border-gray-100">
                                    <div class="flex justify-between items-center mb-4">
                                        <h2 class="text-lg font-semibold text-gray-900">
                                            <?php echo date('F Y'); ?>
                                        </h2>
                                        <div class="flex space-x-1">
                                            <button class="p-1 hover:bg-gray-100 rounded">
                                                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                                                </svg>
                                            </button>
                                            <button class="p-1 hover:bg-gray-100 rounded">
                                                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="grid grid-cols-7 gap-1 text-center text-xs mb-2">
                                        <div class="text-gray-500 font-medium">Su</div>
                                        <div class="text-gray-500 font-medium">Mo</div>
                                        <div class="text-gray-500 font-medium">Tu</div>
                                        <div class="text-gray-500 font-medium">We</div>
                                        <div class="text-gray-500 font-medium">Th</div>
                                        <div class="text-gray-500 font-medium">Fr</div>
                                        <div class="text-gray-500 font-medium">Sa</div>
                                    </div>
                                    
                                    <?php
                                    // Generate mini calendar
                                    $current_month = date('m');
                                    $current_year = date('Y');
                                    $current_day = date('d');
                                    
                                    $num_days = date('t');
                                    $first_day_of_month = date('N', strtotime("$current_year-$current_month-01"));
                                    
                                    // Adjust first day index (1-7) to (0-6)
                                    $first_day_index = $first_day_of_month % 7;
                                    
                                    echo '<div class="grid grid-cols-7 gap-1 text-center">';
                                    
                                    // Empty cells for days before the 1st of month
                                    for ($i = 0; $i < $first_day_index; $i++) {
                                        echo '<div class="h-8 w-8 text-gray-300 flex items-center justify-center"></div>';
                                    }
                                    
                                    // Days of month
                                    for ($day = 1; $day <= $num_days; $day++) {
                                        $is_today = ($day == $current_day);
                                        $has_event = rand(0, 10) > 8; // Random events for demo
                                        
                                        $day_class = $is_today
                                            ? 'h-8 w-8 bg-blue-600 text-white rounded-full flex items-center justify-center'
                                            : 'h-8 w-8 hover:bg-gray-100 rounded-full flex items-center justify-center';
                                        
                                        echo '<div class="relative">';
                                        echo '<div class="' . $day_class . '">' . $day . '</div>';
                                        if ($has_event) {
                                            echo '<div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-blue-500 rounded-full"></div>';
                                        }
                                        echo '</div>';
                                    }
                                    
                                    // Calculate remaining cells to fill out the grid
                                    $remaining_cells = 7 - (($first_day_index + $num_days) % 7);
                                    if ($remaining_cells < 7) {
                                        for ($i = 0; $i < $remaining_cells; $i++) {
                                            echo '<div class="h-8 w-8 text-gray-300 flex items-center justify-center"></div>';
                                        }
                                    }
                                    
                                    echo '</div>';
                                    ?>
                                </div>
                                
                                <!-- Upcoming Events -->
                                <div class="p-4 border-b border-gray-100">
                                    <h2 class="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h2>
                                    
                                    <div class="space-y-3">
                                        <?php
                                        // Get teacher ID
                                        $email = $_SESSION['useremail'];
                                        $query = "SELECT id FROM user WHERE email = '$email'";
                                        $result = mysqli_query($db_conn, $query);
                                        $teacher = mysqli_fetch_object($result);
                                        $teacherId = $teacher->id;
                                        
                                        // Get today's date
                                        $today = date('Y-m-d');
                                        
                                        // Sample events - in a real app, these would come from a database
                                        $events = [
                                            [
                                                'title' => 'Midterm Exam',
                                                'date' => date('Y-m-d', strtotime('+2 days')),
                                                'time' => '10:00 AM - 12:00 PM',
                                                'type' => 'exam'
                                            ],
                                            [
                                                'title' => 'Faculty Meeting',
                                                'date' => date('Y-m-d', strtotime('+1 week')),
                                                'time' => '2:00 PM - 3:30 PM',
                                                'type' => 'meeting'
                                            ],
                                            [
                                                'title' => 'Assignment Deadline',
                                                'date' => date('Y-m-d', strtotime('+3 days')),
                                                'time' => '11:59 PM',
                                                'type' => 'deadline'
                                            ]
                                        ];
                                        
                                        foreach ($events as $event) {
                                            $days_until = (strtotime($event['date']) - strtotime($today)) / (60 * 60 * 24);
                                            $date_formatted = date('M j', strtotime($event['date']));
                                            
                                            $bg_color = '';
                                            $icon = '';
                                            
                                            switch ($event['type']) {
                                                case 'exam':
                                                    $bg_color = 'bg-red-100 text-red-800';
                                                    $icon = '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                                            </svg>';
                                                    break;
                                                case 'meeting':
                                                    $bg_color = 'bg-blue-100 text-blue-800';
                                                    $icon = '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                                            </svg>';
                                                    break;
                                                case 'deadline':
                                                    $bg_color = 'bg-yellow-100 text-yellow-800';
                                                    $icon = '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                            </svg>';
                                                    break;
                                            }
                                            
                                            echo '<div class="flex items-start space-x-3">';
                                            echo '  <div class="flex-shrink-0 rounded-full p-2 ' . $bg_color . '">' . $icon . '</div>';
                                            echo '  <div>';
                                            echo '      <h3 class="text-sm font-medium text-gray-900">' . $event['title'] . '</h3>';
                                            echo '      <p class="text-xs text-gray-500">' . $date_formatted . ' • ' . $event['time'] . '</p>';
                                            echo '      <p class="text-xs font-medium ' . (($days_until <= 2) ? 'text-red-600' : 'text-gray-500') . ' mt-1">';
                                            
                                            if ($days_until < 1) {
                                                echo 'Today';
                                            } elseif ($days_until < 2) {
                                                echo 'Tomorrow';
                                            } else {
                                                echo 'In ' . floor($days_until) . ' days';
                                            }
                                            
                                            echo '      </p>';
                                            echo '  </div>';
                                            echo '</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                                
                                <!-- Create Event Button -->
                                <div class="p-4">
                                    <button class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                        </svg>
                                        Create New Event
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Main Calendar - Right Side -->
                        <div class="lg:col-span-9">
                            <div class="bg-white shadow rounded-xl overflow-hidden">
                                <!-- Calendar Header -->
                                <div class="p-4 border-b border-gray-100 flex items-center justify-between">
                                    <div class="flex items-center space-x-2">
                                        <h2 class="text-xl font-bold text-gray-900">
                                            <?php echo date('F Y'); ?>
                                        </h2>
                                        <div class="flex space-x-1">
                                            <button class="p-1 hover:bg-gray-100 rounded">
                                                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                                                </svg>
                                            </button>
                                            <button class="p-1 hover:bg-gray-100 rounded">
                                                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <button class="ml-2 px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-lg hover:bg-blue-200">
                                            Today
                                        </button>
                                    </div>
                                    <div class="flex space-x-2">
                                        <button class="px-3 py-1 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50 text-gray-700">
                                            Day
                                        </button>
                                        <button class="px-3 py-1 bg-blue-600 text-white rounded-lg text-sm font-medium">
                                            Week
                                        </button>
                                        <button class="px-3 py-1 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50 text-gray-700">
                                            Month
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- Week Calendar View -->
                                <div class="overflow-x-auto">
                                    <div class="min-w-[800px]">
                                        <!-- Days of Week Header -->
                                        <div class="grid grid-cols-7 border-b border-gray-200">
                                            <?php
                                            $current_date = date('Y-m-d');
                                            $week_start = date('Y-m-d', strtotime('this week monday', strtotime($current_date)));
                                            
                                            for ($i = 0; $i < 7; $i++) {
                                                $day_date = date('Y-m-d', strtotime($week_start . ' +' . $i . ' days'));
                                                $day_name = date('D', strtotime($day_date));
                                                $day_num = date('j', strtotime($day_date));
                                                $is_today = ($day_date == $current_date);
                                                
                                                $header_class = $is_today
                                                    ? 'p-2 text-center border-r border-gray-200 bg-blue-50'
                                                    : 'p-2 text-center border-r border-gray-200';
                                                
                                                echo '<div class="' . $header_class . '">';
                                                echo '<p class="text-sm font-medium text-gray-500">' . $day_name . '</p>';
                                                
                                                if ($is_today) {
                                                    echo '<div class="mt-1 w-8 h-8 mx-auto bg-blue-600 rounded-full flex items-center justify-center">';
                                                    echo '<span class="text-sm font-medium text-white">' . $day_num . '</span>';
                                                    echo '</div>';
                                                } else {
                                                    echo '<div class="mt-1 w-8 h-8 mx-auto flex items-center justify-center">';
                                                    echo '<span class="text-sm font-medium text-gray-900">' . $day_num . '</span>';
                                                    echo '</div>';
                                                }
                                                
                                                echo '</div>';
                                            }
                                            ?>
                                        </div>
                                        
                                        <!-- Time Grid -->
                                        <div class="relative" style="height: 600px;">
                                            <!-- Time Labels -->
                                            <div class="absolute top-0 left-0 w-16 h-full border-r border-gray-200">
                                                <?php
                                                for ($hour = 8; $hour <= 18; $hour++) {
                                                    $time = $hour <= 12 ? $hour . ' AM' : ($hour - 12) . ' PM';
                                                    if ($hour == 12) $time = '12 PM';
                                                    
                                                    $top = (($hour - 8) / 11) * 100;
                                                    
                                                    echo '<div class="absolute text-xs font-medium text-gray-500" style="top: ' . $top . '%;">';
                                                    echo $time;
                                                    echo '</div>';
                                                }
                                                ?>
                                            </div>
                                            
                                            <!-- Day Columns -->
                                            <div class="ml-16 grid grid-cols-7 h-full">
                                                <?php
                                                // Generate day columns with hour lines
                                                for ($day = 0; $day < 7; $day++) {
                                                    echo '<div class="relative border-r border-gray-200 h-full">';
                                                    
                                                    // Hour lines
                                                    for ($hour = 8; $hour <= 18; $hour++) {
                                                        $top = (($hour - 8) / 11) * 100;
                                                        echo '<div class="absolute w-full border-t border-gray-100" style="top: ' . $top . '%;"></div>';
                                                    }
                                                    
                                                    // Generate random events for demo
                                                    $day_date = date('Y-m-d', strtotime($week_start . ' +' . $day . ' days'));
                                                    
                                                    if ($day == 1) { // Tuesday
                                                        // Add a class event
                                                        echo '<div class="absolute w-[95%] left-[2.5%] bg-blue-100 border-l-4 border-blue-600 rounded-r-lg p-2" style="top: 10%; height: 15%;">';
                                                        echo '<p class="text-xs font-medium text-blue-800">Database Management</p>';
                                                        echo '<p class="text-xs text-blue-600">9:00 - 10:30 AM</p>';
                                                        echo '</div>';
                                                    }
                                                    
                                                    if ($day == 2) { // Wednesday
                                                        // Add a faculty meeting
                                                        echo '<div class="absolute w-[95%] left-[2.5%] bg-purple-100 border-l-4 border-purple-600 rounded-r-lg p-2" style="top: 45%; height: 10%;">';
                                                        echo '<p class="text-xs font-medium text-purple-800">Faculty Meeting</p>';
                                                        echo '<p class="text-xs text-purple-600">1:00 - 2:00 PM</p>';
                                                        echo '</div>';
                                                    }
                                                    
                                                    if ($day == 4) { // Friday
                                                        // Add an exam
                                                        echo '<div class="absolute w-[95%] left-[2.5%] bg-red-100 border-l-4 border-red-600 rounded-r-lg p-2" style="top: 20%; height: 20%;">';
                                                        echo '<p class="text-xs font-medium text-red-800">Midterm Exam</p>';
                                                        echo '<p class="text-xs text-red-600">10:00 AM - 12:00 PM</p>';
                                                        echo '</div>';
                                                    }
                                                    
                                                    echo '</div>';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
    // Simple calendar logic
    document.addEventListener('DOMContentLoaded', function() {
        // This would normally handle date switching, view changes, etc.
        console.log('Calendar initialized');
    });
</script>

<?php include("../public/footer.php"); ?>
