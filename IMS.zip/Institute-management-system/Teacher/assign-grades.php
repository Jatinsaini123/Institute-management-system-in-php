<?php 
include("../actions/checkteacher.php");
include("../public/header.php");
include("../includes/config.php");
?>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="py-8 px-6">
                <div class="max-w-6xl mx-auto">
                    <!-- Header Section -->
                    <div class="mb-6">
                        <h1 class="text-2xl font-bold text-gray-900 mb-2">Student Marks Assignment</h1>
                        <p class="text-sm text-gray-600">Evaluate and record student performance in your subjects</p>
                    </div>

                    <!-- Main Content Area -->
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        <!-- Selection Panel - Left Side -->
                        <div class="lg:col-span-4">
                            <div class="bg-white shadow rounded-xl overflow-hidden">
                                <div class="p-6 border-b border-gray-100">
                                    <h2 class="text-lg font-semibold text-gray-900">Select Class</h2>
                                    <p class="text-sm text-gray-500 mt-1">Choose class details to assign marks</p>
                                </div>
                                
                                <div class="p-6">
                                    <form action="" method="POST" class="space-y-5">
                                        <!-- Year Selection -->
                                        <div>
                                            <label for="year" class="block text-sm font-medium text-gray-700 mb-1">Academic Year</label>
                                            <select name="year" id="year" class="block w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500 text-gray-900" required>
                                                <option value="">Select Year</option>
                                                <?php
                                                $years = mysqli_query($db_conn, "SELECT * FROM years");
                                                while ($year = mysqli_fetch_object($years)) {
                                                    echo "<option value='{$year->id}'>{$year->year}</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <!-- Department Selection -->
                                        <div>
                                            <label for="department" class="block text-sm font-medium text-gray-700 mb-1">Department</label>
                                            <select name="dept" id="department" class="block w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500 text-gray-900" required>
                                                <option value="">Select Department</option>
                                                <?php
                                                $departments = mysqli_query($db_conn, "SELECT * FROM department");
                                                while ($dept = mysqli_fetch_object($departments)) {
                                                    echo "<option value='{$dept->id}'>" . ucfirst($dept->name) . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <!-- Section Selection -->
                                        <div>
                                            <label for="section" class="block text-sm font-medium text-gray-700 mb-1">Section</label>
                                            <select name="sec" id="section" class="block w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500 text-gray-900" required>
                                                <option value="">Select Section</option>
                                                <?php
                                                $sections = mysqli_query($db_conn, "SELECT * FROM section");
                                                while ($section = mysqli_fetch_object($sections)) {
                                                    echo "<option value='{$section->id}'>" . ucfirst($section->name) . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <!-- Exam Selection -->
                                        <div>
                                            <label for="exam" class="block text-sm font-medium text-gray-700 mb-1">Examination</label>
                                            <select name="exam" id="exam" class="block w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500 text-gray-900" required>
                                                <option value="">Select Exam</option>
                                                <?php
                                                $exams = mysqli_query($db_conn, "SELECT * FROM exam");
                                                while ($exam = mysqli_fetch_object($exams)) {
                                                    echo "<option value='{$exam->id}'>" . ucfirst($exam->examname) . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <div class="pt-2">
                                            <button type="submit" name="assignmarks" 
                                                    class="w-full text-white bg-gradient-to-r from-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                                <div class="flex items-center justify-center">
                                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                                    </svg>
                                                    Load Student List
                                                </div>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                
                                <!-- Info Card -->
                                <div class="p-6 bg-blue-50 border-t border-blue-100">
                                    <div class="flex items-start space-x-3">
                                        <div class="flex-shrink-0">
                                            <svg class="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <div>
                                            <h3 class="text-sm font-medium text-blue-800">Grading Tips</h3>
                                            <p class="text-sm text-blue-700 mt-1">Enter marks for each student based on their performance in the selected exam.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Grades Form - Right Side -->
                        <div class="lg:col-span-8">
                            <?php if(isset($_POST['assignmarks'])): 
                                // Get teacher's subject and verify allocation
                                $email = $_SESSION['useremail'];
                                $year = $_POST['year'];
                                $dept = $_POST['dept'];
                                $sec = $_POST['sec'];
                                $exam = $_POST['exam'];

                                // Get teacher's subject allocation
                                $query = "SELECT a.subjectid, s.name as subject_name, e.totalmarks, e.examname 
                                         FROM allotment a 
                                         JOIN subject s ON a.subjectid = s.id 
                                         JOIN exam e ON e.id = '$exam'
                                         WHERE a.teacherid = (SELECT id FROM user WHERE email = '$email')
                                         AND a.yearid = '$year' 
                                         AND a.departmentid = '$dept' 
                                         AND a.sectionid = '$sec'";
                                $result = mysqli_query($db_conn, $query);

                                if(mysqli_num_rows($result) == 0) {
                                    echo '<div class="h-full flex items-center justify-center">
                                            <div class="bg-white shadow rounded-xl p-8 max-w-lg text-center">
                                                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-4">
                                                    <svg class="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                    </svg>
                                                </div>
                                                <h3 class="text-xl font-bold text-gray-900 mb-2">Not Authorized</h3>
                                                <p class="text-gray-600 mb-6">You are not assigned to grade students for this class. Please select a class that has been allocated to you.</p>
                                                <button onclick="history.back()" class="text-blue-600 font-medium hover:text-blue-800">
                                                    ← Go back and select another class
                                                </button>
                                            </div>
                                          </div>';
                                } else {
                                    $subject_info = mysqli_fetch_object($result);
                            ?>
                                    <!-- Marks Assignment Form -->
                                    <div class="bg-white shadow rounded-xl overflow-hidden">
                                        <div class="p-6 bg-gradient-to-r from-blue-600 to-blue-800 border-b">
                                            <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                                                <div class="mb-4 md:mb-0">
                                                    <h2 class="text-xl font-bold text-white">Mark Sheet</h2>
                                                    <p class="text-blue-100">
                                                        <?php echo $subject_info->subject_name; ?> • 
                                                        <?php echo $subject_info->examname; ?>
                                                    </p>
                                                </div>
                                                <div class="px-4 py-2 bg-white bg-opacity-20 backdrop-filter backdrop-blur-lg rounded-lg">
                                                    <span class="text-white font-medium">
                                                        Maximum Marks: <?php echo $subject_info->totalmarks; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <form method="POST" id="marksForm">
                                            <input type="hidden" name="year" value="<?php echo $year; ?>">
                                            <input type="hidden" name="dept" value="<?php echo $dept; ?>">
                                            <input type="hidden" name="sec" value="<?php echo $sec; ?>">
                                            <input type="hidden" name="exam" value="<?php echo $exam; ?>">

                                            <!-- Student List -->
                                            <div class="overflow-hidden">
                                                <div class="overflow-x-auto">
                                                    <table class="min-w-full divide-y divide-gray-200">
                                                        <thead class="bg-gray-50">
                                                            <tr>
                                                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Roll No</th>
                                                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student Name</th>
                                                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Previous Marks</th>
                                                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marks</th>
                                                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $query = "SELECT s.id, s.rollno, u.firstname, u.lastname, IFNULL(m.mark, '') as previous_mark
                                                                     FROM student s 
                                                                     JOIN user u ON s.id = u.id 
                                                                     LEFT JOIN marks m ON s.id = m.studentid 
                                                                        AND m.examid = '$exam' 
                                                                        AND m.subjectid = '{$subject_info->subjectid}'
                                                                     WHERE s.yearid = '$year' 
                                                                     AND s.departmentid = '$dept' 
                                                                     AND s.sectionid = '$sec' 
                                                                     ORDER BY s.rollno";
                                                            $students = mysqli_query($db_conn, $query);
                                                            $rowCount = 0;
                                                            
                                                            while($student = mysqli_fetch_object($students)):
                                                                $rowCount++;
                                                                $rowClass = $rowCount % 2 === 0 ? 'bg-gray-50' : 'bg-white';
                                                                
                                                                // Determine status based on previous mark
                                                                $status = '';
                                                                $statusClass = '';
                                                                
                                                                if($student->previous_mark !== '') {
                                                                    $status = 'Graded';
                                                                    $statusClass = 'bg-green-100 text-green-800';
                                                                } else {
                                                                    $status = 'Pending';
                                                                    $statusClass = 'bg-yellow-100 text-yellow-800';
                                                                }
                                                            ?>
                                                                <tr class="<?php echo $rowClass; ?> hover:bg-gray-100 transition-colors">
                                                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                                        <?php echo $student->rollno; ?>
                                                                    </td>
                                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                                        <?php echo ucfirst($student->firstname) . ' ' . ucfirst($student->lastname); ?>
                                                                    </td>
                                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                                        <?php echo $student->previous_mark ? $student->previous_mark : 'Not assigned'; ?>
                                                                    </td>
                                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                                        <input type="number" 
                                                                               name="marks[<?php echo $student->id; ?>]" 
                                                                               id="mark-<?php echo $student->id; ?>"
                                                                               value="<?php echo $student->previous_mark; ?>"
                                                                               min="0" 
                                                                               max="<?php echo $subject_info->totalmarks; ?>" 
                                                                               class="w-24 rounded-md border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                                                                               onchange="updateStatus('<?php echo $student->id; ?>')"
                                                                               required>
                                                                    </td>
                                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                                        <span id="status-<?php echo $student->id; ?>" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                                                            <?php echo $status; ?>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                            <?php endwhile; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>

                                            <!-- Action Buttons -->
                                            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
                                                <div>
                                                    <button type="button" onclick="autoFill()" 
                                                            class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                        <svg class="w-4 h-4 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                        Auto Fill Pending
                                                    </button>
                                                </div>
                                                <div>
                                                    <button type="submit" name="submitmarks" 
                                                            class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                        Save All Marks
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                            <?php 
                                }
                            else: 
                            ?>
                                <!-- Empty State -->
                                <div class="bg-white shadow rounded-xl p-8 flex flex-col items-center justify-center h-96">
                                    <div class="text-center">
                                        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-6">
                                            <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                            </svg>
                                        </div>
                                        <h3 class="text-xl font-bold text-gray-900 mb-2">Grading System</h3>
                                        <p class="text-gray-600 max-w-sm mx-auto mb-6">
                                            Use the form on the left to select a class and exam to assign marks to your students.
                                        </p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
    // Update status indicator when marks are changed
    function updateStatus(studentId) {
        const statusElement = document.getElementById(`status-${studentId}`);
        
        statusElement.className = 'px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800';
        statusElement.textContent = 'Graded';
    }
    
    // Auto fill empty mark fields with a default value
    function autoFill() {
        if(confirm('This will automatically fill all empty mark fields with zeros. Continue?')) {
            const inputs = document.querySelectorAll('input[type="number"]');
            inputs.forEach(input => {
                if(input.value === '') {
                    input.value = '0';
                    const studentId = input.id.replace('mark-', '');
                    updateStatus(studentId);
                }
            });
        }
    }
</script>

<?php
// Process marks submission
if(isset($_POST['submitmarks'])) {
    $year = $_POST['year'];
    $dept = $_POST['dept'];
    $sec = $_POST['sec'];
    $exam = $_POST['exam'];
    
    // Get subject ID
    $email = $_SESSION['useremail'];
    $query = "SELECT subjectid FROM allotment 
              WHERE teacherid = (SELECT id FROM user WHERE email = '$email')
              AND yearid = '$year' 
              AND departmentid = '$dept' 
              AND sectionid = '$sec'";
    $result = mysqli_query($db_conn, $query);
    
    if($subject = mysqli_fetch_object($result)) {
        $subject_id = $subject->subjectid;
        
        foreach($_POST['marks'] as $student_id => $mark) {
            // Validate mark
            $mark = filter_var($mark, FILTER_VALIDATE_INT);
            if($mark === false || $mark < 0) continue;

            // Check if marks already exist
            $check_query = "SELECT id FROM marks 
                           WHERE studentid = '$student_id' 
                           AND examid = '$exam' 
                           AND subjectid = '$subject_id'";
            $check_result = mysqli_query($db_conn, $check_query);

            if(mysqli_num_rows($check_result) > 0) {
                // Update existing marks
                $update_query = "UPDATE marks 
                               SET mark = '$mark' 
                               WHERE studentid = '$student_id' 
                               AND examid = '$exam' 
                               AND subjectid = '$subject_id'";
                mysqli_query($db_conn, $update_query);
            } else {
                // Insert new marks
                $insert_query = "INSERT INTO marks (studentid, yearid, examid, subjectid, mark) 
                               VALUES ('$student_id', '$year', '$exam', '$subject_id', '$mark')";
                mysqli_query($db_conn, $insert_query);
            }
        }

        echo "<script>
                alert('Marks have been saved successfully!');
                window.location.href = 'grading.php';
              </script>";
    }
}
?>

<?php include("../public/footer.php"); ?>