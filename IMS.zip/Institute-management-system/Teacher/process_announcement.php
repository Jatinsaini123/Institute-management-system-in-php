<?php
session_start();
include("../includes/config.php");

// Check if teacher is logged in
if (!isset($_SESSION['teacheremail'])) {
    header("Location: ../Login/login.php");
    exit();
}

// Create announcements table if it doesn't exist
$createTableSQL = "CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id VARCHAR(50) NOT NULL,
    teacher_email VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    priority ENUM('normal', 'important', 'urgent') DEFAULT 'normal',
    created_at DATETIME NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (class_id),
    INDEX (teacher_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

$db_conn->query($createTableSQL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $class_id = $_POST['class_id'];
    $priority = $_POST['priority'];
    $title = $_POST['title'];
    $message = $_POST['message'];
    $teacher_email = $_SESSION['teacheremail'];
    $created_at = date('Y-m-d H:i:s');

    try {
        // Insert announcement
        $sql = "INSERT INTO announcements (class_id, teacher_email, title, message, priority, created_at) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $db_conn->prepare($sql);
        $stmt->bind_param("ssssss", $class_id, $teacher_email, $title, $message, $priority, $created_at);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Announcement posted successfully!";
        } else {
            $_SESSION['error_message'] = "Error posting announcement. Please try again.";
        }

    } catch (Exception $e) {
        $_SESSION['error_message'] = "An error occurred. Please try again later.";
    }

    header("Location: announcements.php");
    exit();
}

// Get announcements for display
try {
    $teacher_email = $_SESSION['teacheremail'];
    
    // Join with classes table to get class names
    $query = "SELECT a.*, c.class_name 
              FROM announcements a 
              LEFT JOIN classes c ON a.class_id = c.class_id 
              WHERE a.teacher_email = ? 
              ORDER BY a.created_at DESC";
    
    $stmt = $db_conn->prepare($query);
    $stmt->bind_param("s", $teacher_email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $announcements = [];
    while ($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }

    // Update the announcements array in announcements.php
    $_SESSION['announcements'] = $announcements;

} catch (Exception $e) {
    $_SESSION['error_message'] = "Error fetching announcements.";
}

// Close database connection
$db_conn->close();

// Redirect back to announcements page
header("Location: announcements.php");
exit();
?>
