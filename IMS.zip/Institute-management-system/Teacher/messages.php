<?php 
include("../actions/checkteacher.php");
include("../public/header.php");
include("../includes/config.php");
?>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="py-8 px-6">
                <div class="max-w-6xl mx-auto">
                    <!-- Header Section -->
                    <div class="mb-6">
                        <h1 class="text-2xl font-bold text-gray-900 mb-2">Messages</h1>
                        <p class="text-sm text-gray-600">Communicate with students and colleagues</p>
                    </div>

                    <!-- Main Content Area -->
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        <!-- Contacts Panel - Left Side -->
                        <div class="lg:col-span-4">
                            <div class="bg-white shadow rounded-xl overflow-hidden">
                                <div class="p-4 border-b border-gray-100 flex justify-between items-center">
                                    <h2 class="text-lg font-semibold text-gray-900">Contacts</h2>
                                    <div class="relative">
                                        <input type="text" placeholder="Search" class="pl-8 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        <svg class="w-4 h-4 absolute left-2.5 top-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                        </svg>
                                    </div>
                                </div>
                                
                                <!-- Contact List -->
                                <div class="overflow-y-auto h-[calc(100vh-280px)] scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                                    <div class="px-2">
                                        <!-- Contact Category -->
                                        <h3 class="text-xs font-semibold text-gray-500 px-3 py-2 uppercase">Students</h3>
                                        
                                        <!-- Contact Items -->
                                        <?php
                                        // Get teacher ID
                                        $email = $_SESSION['useremail'];
                                        $query = "SELECT id FROM user WHERE email = '$email'";
                                        $result = mysqli_query($db_conn, $query);
                                        $teacher = mysqli_fetch_object($result);
                                        $teacherId = $teacher->id;
                                        
                                        // Get students from teacher's allocated classes
                                        $query = "SELECT DISTINCT s.id, u.firstname, u.lastname, u.email, d.name as dept_name, sec.name as section_name 
                                                FROM student s 
                                                JOIN user u ON s.id = u.id
                                                JOIN department d ON s.departmentid = d.id
                                                JOIN section sec ON s.sectionid = sec.id
                                                JOIN allotment a ON s.departmentid = a.departmentid AND s.sectionid = a.sectionid
                                                WHERE a.teacherid = '$teacherId'
                                                ORDER BY u.firstname
                                                LIMIT 15";
                                        $students = mysqli_query($db_conn, $query);
                                        
                                        $counter = 0;
                                        while($student = mysqli_fetch_object($students)):
                                            $isActive = $counter === 0 ? 'bg-blue-50' : '';
                                            $initials = strtoupper(substr($student->firstname, 0, 1) . substr($student->lastname, 0, 1));
                                            $counter++;
                                        ?>
                                        <div class="contact-item p-3 rounded-lg flex items-center space-x-3 cursor-pointer hover:bg-gray-50 <?php echo $isActive; ?>">
                                            <div class="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-medium">
                                                <?php echo $initials; ?>
                                            </div>
                                            <div class="flex-1 min-w-0">
                                                <p class="text-sm font-medium text-gray-900 truncate">
                                                    <?php echo ucfirst($student->firstname) . ' ' . ucfirst($student->lastname); ?>
                                                </p>
                                                <p class="text-xs text-gray-500 truncate">
                                                    <?php echo ucfirst($student->dept_name) . ' - Section ' . ucfirst($student->section_name); ?>
                                                </p>
                                            </div>
                                            <div class="bg-blue-500 rounded-full w-2 h-2"></div>
                                        </div>
                                        <?php endwhile; ?>
                                        
                                        <!-- Faculty Category -->
                                        <h3 class="text-xs font-semibold text-gray-500 px-3 py-2 uppercase mt-4">Faculty</h3>
                                        
                                        <!-- Faculty Contact Items -->
                                        <?php
                                        // Get other teachers
                                        $query = "SELECT u.id, u.firstname, u.lastname, u.email 
                                                FROM user u 
                                                JOIN teacher t ON u.id = t.id
                                                WHERE u.id != '$teacherId'
                                                ORDER BY u.firstname
                                                LIMIT 5";
                                        $teachers = mysqli_query($db_conn, $query);
                                        
                                        while($teacher = mysqli_fetch_object($teachers)):
                                            $initials = strtoupper(substr($teacher->firstname, 0, 1) . substr($teacher->lastname, 0, 1));
                                        ?>
                                        <div class="contact-item p-3 rounded-lg flex items-center space-x-3 cursor-pointer hover:bg-gray-50">
                                            <div class="flex-shrink-0 w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center font-medium">
                                                <?php echo $initials; ?>
                                            </div>
                                            <div class="flex-1 min-w-0">
                                                <p class="text-sm font-medium text-gray-900 truncate">
                                                    <?php echo ucfirst($teacher->firstname) . ' ' . ucfirst($teacher->lastname); ?>
                                                </p>
                                                <p class="text-xs text-gray-500 truncate">
                                                    Faculty Member
                                                </p>
                                            </div>
                                        </div>
                                        <?php endwhile; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Message Content - Right Side -->
                        <div class="lg:col-span-8">
                            <div class="bg-white shadow rounded-xl overflow-hidden flex flex-col h-[calc(100vh-180px)]">
                                <!-- Chat Header -->
                                <div class="p-4 border-b border-gray-100 flex items-center space-x-3">
                                    <div class="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-medium">
                                        <?php
                                        $query = "SELECT u.firstname, u.lastname FROM student s 
                                                  JOIN user u ON s.id = u.id 
                                                  LIMIT 1";
                                        $first_student = mysqli_query($db_conn, $query);
                                        $student = mysqli_fetch_object($first_student);
                                        $first_initials = strtoupper(substr($student->firstname, 0, 1) . substr($student->lastname, 0, 1));
                                        echo $first_initials;
                                        ?>
                                    </div>
                                    <div>
                                        <h3 class="text-sm font-medium text-gray-900">
                                            <?php echo ucfirst($student->firstname) . ' ' . ucfirst($student->lastname); ?>
                                        </h3>
                                        <p class="text-xs text-gray-500">Online</p>
                                    </div>
                                    <div class="ml-auto flex items-center space-x-2">
                                        <button class="p-2 rounded-full hover:bg-gray-100">
                                            <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                            </svg>
                                        </button>
                                        <button class="p-2 rounded-full hover:bg-gray-100">
                                            <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                                            </svg>
                                        </button>
                                        <button class="p-2 rounded-full hover:bg-gray-100">
                                            <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- Chat Messages -->
                                <div class="flex-1 p-4 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                                    <!-- Today Marker -->
                                    <div class="flex items-center my-6">
                                        <div class="flex-grow border-t border-gray-200"></div>
                                        <span class="flex-shrink-0 text-xs text-gray-500 px-3">Today</span>
                                        <div class="flex-grow border-t border-gray-200"></div>
                                    </div>

                                    <!-- Example Messages -->
                                    <div class="flex flex-col space-y-4">
                                        <!-- Received Message -->
                                        <div class="flex items-end">
                                            <div class="flex-shrink-0 mr-3">
                                                <div class="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-medium">
                                                    <?php echo $first_initials; ?>
                                                </div>
                                            </div>
                                            <div class="bg-gray-100 rounded-lg rounded-bl-none p-3 max-w-md">
                                                <p class="text-sm text-gray-800">Hello Professor, I had a question about the assignment due next week. Is it possible to get an extension?</p>
                                                <p class="text-xs text-gray-500 mt-1">10:32 AM</p>
                                            </div>
                                        </div>

                                        <!-- Sent Message -->
                                        <div class="flex items-end justify-end">
                                            <div class="bg-blue-600 rounded-lg rounded-br-none p-3 max-w-md">
                                                <p class="text-sm text-white">Hi there! I can grant you a 2-day extension. Please make sure to submit it by then.</p>
                                                <p class="text-xs text-blue-200 mt-1">10:45 AM</p>
                                            </div>
                                            <div class="flex-shrink-0 ml-3">
                                                <div class="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs font-medium">
                                                    <?php
                                                    $teacher_query = "SELECT firstname, lastname FROM user WHERE email = '$email'";
                                                    $teacher_result = mysqli_query($db_conn, $teacher_query);
                                                    $teacher_data = mysqli_fetch_object($teacher_result);
                                                    echo strtoupper(substr($teacher_data->firstname, 0, 1) . substr($teacher_data->lastname, 0, 1));
                                                    ?>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Received Message -->
                                        <div class="flex items-end">
                                            <div class="flex-shrink-0 mr-3">
                                                <div class="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-medium">
                                                    <?php echo $first_initials; ?>
                                                </div>
                                            </div>
                                            <div class="bg-gray-100 rounded-lg rounded-bl-none p-3 max-w-md">
                                                <p class="text-sm text-gray-800">Thank you so much! I really appreciate it. I'll make sure it's submitted on time.</p>
                                                <p class="text-xs text-gray-500 mt-1">10:51 AM</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Message Input -->
                                <div class="px-4 py-3 border-t border-gray-200">
                                    <form class="flex items-center space-x-2">
                                        <button type="button" class="p-2 text-gray-500 rounded-full hover:bg-gray-100">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path>
                                            </svg>
                                        </button>
                                        <input type="text" placeholder="Type your message..." class="flex-1 py-2 px-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        <button type="button" class="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
    // Make contact items clickable
    document.querySelectorAll('.contact-item').forEach(item => {
        item.addEventListener('click', function() {
            // Remove active class from all items
            document.querySelectorAll('.contact-item').forEach(el => {
                el.classList.remove('bg-blue-50');
            });
            
            // Add active class to clicked item
            this.classList.add('bg-blue-50');
            
            // In a real app, this would load the conversation with this contact
            // For now, we'll just show a notification
            const name = this.querySelector('.text-gray-900').textContent.trim();
            console.log(`Loading conversation with ${name}`);
        });
    });
</script>

<?php include("../public/footer.php"); ?>
