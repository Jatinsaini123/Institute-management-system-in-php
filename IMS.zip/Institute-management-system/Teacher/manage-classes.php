<?php include("../actions/checkteacher.php") ?>
<?php include("../public/header.php") ?>
<?php include("../includes/config.php") ?>

<div class="flex overflow-hidden bg-white">
  
<!-- Aside | Sidebar -->
<?php include("sidebar.php") ?>

  <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
  <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
    <main>
      <div class="py-8 px-6">
        <div class="max-w-6xl mx-auto">
          <!-- Header Section -->
          <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 mb-2">My Teaching Subjects</h1>
            <p class="text-sm text-gray-600">Manage your assigned courses and materials</p>
          </div>

          <!-- Stats Cards -->
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <!-- Total Subjects Card -->
            <div class="bg-white rounded-xl shadow overflow-hidden">
              <div class="p-5">
                <div class="flex items-center">
                  <div class="flex-shrink-0 bg-blue-100 rounded-md p-3">
                    <svg class="h-8 w-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                    </svg>
                  </div>
                  <div class="ml-5">
                    <div class="text-3xl font-semibold text-gray-900">
                      <?php
                      // Count teacher's subjects
                      $teacher_email = $_SESSION['useremail'];
                      $query = "SELECT COUNT(DISTINCT a.subjectid) as count FROM allotment a 
                                JOIN user u ON a.teacherid = u.id 
                                WHERE u.email = '$teacher_email'";
                      $result = mysqli_query($db_conn, $query);
                      $row = mysqli_fetch_object($result);
                      echo $row->count;
                      ?>
                    </div>
                    <div class="text-sm font-medium text-gray-500">Total Subjects</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Departments Card -->
            <div class="bg-white rounded-xl shadow overflow-hidden">
              <div class="p-5">
                <div class="flex items-center">
                  <div class="flex-shrink-0 bg-green-100 rounded-md p-3">
                    <svg class="h-8 w-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                    </svg>
                  </div>
                  <div class="ml-5">
                    <div class="text-3xl font-semibold text-gray-900">
                      <?php
                      // Count departments
                      $query = "SELECT COUNT(DISTINCT a.departmentid) as count FROM allotment a 
                                JOIN user u ON a.teacherid = u.id 
                                WHERE u.email = '$teacher_email'";
                      $result = mysqli_query($db_conn, $query);
                      $row = mysqli_fetch_object($result);
                      echo $row->count;
                      ?>
                    </div>
                    <div class="text-sm font-medium text-gray-500">Departments</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Classes Card -->
            <div class="bg-white rounded-xl shadow overflow-hidden">
              <div class="p-5">
                <div class="flex items-center">
                  <div class="flex-shrink-0 bg-purple-100 rounded-md p-3">
                    <svg class="h-8 w-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                    </svg>
                  </div>
                  <div class="ml-5">
                    <div class="text-3xl font-semibold text-gray-900">
                      <?php
                      // Count classes
                      $query = "SELECT COUNT(*) as count FROM allotment a 
                                JOIN user u ON a.teacherid = u.id 
                                WHERE u.email = '$teacher_email'";
                      $result = mysqli_query($db_conn, $query);
                      $row = mysqli_fetch_object($result);
                      echo $row->count;
                      ?>
                    </div>
                    <div class="text-sm font-medium text-gray-500">Total Classes</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Subjects Table Card -->
          <div class="bg-white shadow rounded-xl overflow-hidden">
            <div class="p-6 border-b border-gray-100">
              <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 class="text-lg font-semibold text-gray-900">My Assigned Subjects</h2>
                  <p class="text-sm text-gray-500 mt-1">View and manage your teaching subjects</p>
                </div>
                <div class="mt-4 md:mt-0">
                  <div class="relative">
                    <input type="text" id="search-subjects" placeholder="Search subjects..." 
                           class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Code</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Name</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Year</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Section</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  <?php
                  // Get teacher ID
                  $query = "SELECT id FROM user WHERE email = '$teacher_email'";
                  $result = mysqli_query($db_conn, $query);
                  $teacher = mysqli_fetch_object($result);
                  $teacherId = $teacher->id;

                  // Fetch subjects with details
                  $query = "SELECT s.id, s.name, s.subject_code, d.name as department, y.year, sec.name as section, a.yearid, a.departmentid, a.sectionid 
                           FROM allotment a 
                           JOIN subject s ON a.subjectid = s.id 
                           JOIN department d ON a.departmentid = d.id 
                           JOIN years y ON a.yearid = y.id 
                           JOIN section sec ON a.sectionid = sec.id 
                           WHERE a.teacherid = '$teacherId'
                           ORDER BY d.name, y.year, sec.name";
                  $subjects = mysqli_query($db_conn, $query);
                  
                  if(mysqli_num_rows($subjects) == 0) {
                    echo '<tr><td colspan="6" class="px-6 py-8 text-center text-gray-500">No subjects assigned yet</td></tr>';
                  }

                  $row_count = 0;
                  while($subject = mysqli_fetch_object($subjects)):
                    $row_count++;
                    $row_bg = $row_count % 2 == 0 ? 'bg-gray-50' : 'bg-white';
                  ?>
                    <tr class="<?php echo $row_bg; ?> hover:bg-gray-100 subject-row" data-subject="<?php echo strtolower($subject->name); ?>">
                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        <?php echo $subject->subject_code; ?>
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        <?php echo $subject->name; ?>
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        <?php echo ucfirst($subject->department); ?>
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        <?php echo $subject->year; ?>
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        <?php echo ucfirst($subject->section); ?>
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div class="flex space-x-3">
                          <a href="attendance.php?year=<?php echo $subject->yearid; ?>&dept=<?php echo $subject->departmentid; ?>&sec=<?php echo $subject->sectionid; ?>" 
                             class="text-blue-600 hover:text-blue-900 flex items-center">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                            </svg>
                            Attendance
                          </a>
                          <a href="upload-materials.php?subject=<?php echo $subject->id; ?>" 
                             class="text-green-600 hover:text-green-900 flex items-center">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0l-4 4m4-4v12"></path>
                            </svg>
                            Materials
                          </a>
                        </div>
                      </td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>

            <!-- Pagination or Empty State -->
            <?php if(mysqli_num_rows($subjects) > 0): ?>
              <div class="px-6 py-4 border-t border-gray-200 bg-gray-50">
                <div class="text-sm text-gray-600">
                  Showing <?php echo mysqli_num_rows($subjects); ?> subjects
                </div>
              </div>
            <?php endif; ?>
          </div>

          <!-- Quick Access Cards -->
          <div class="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Attendance Card -->
            <div class="bg-white rounded-xl shadow overflow-hidden">
              <div class="p-5">
                <div class="flex items-center mb-4">
                  <div class="flex-shrink-0 bg-blue-100 rounded-md p-2">
                    <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                    </svg>
                  </div>
                  <h3 class="ml-3 text-lg font-semibold text-gray-900">Attendance Management</h3>
                </div>
                <p class="text-sm text-gray-600 mb-4">Record and manage student attendance for your classes</p>
                <a href="attendance.php" class="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center">
                  Take Attendance
                  <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                  </svg>
                </a>
              </div>
            </div>

            <!-- Materials Card -->
            <div class="bg-white rounded-xl shadow overflow-hidden">
              <div class="p-5">
                <div class="flex items-center mb-4">
                  <div class="flex-shrink-0 bg-green-100 rounded-md p-2">
                    <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0l-4 4m4-4v12"></path>
                    </svg>
                  </div>
                  <h3 class="ml-3 text-lg font-semibold text-gray-900">Learning Materials</h3>
                </div>
                <p class="text-sm text-gray-600 mb-4">Upload and manage study materials for your students</p>
                <a href="upload-materials.php" class="text-green-600 hover:text-green-800 text-sm font-medium flex items-center">
                  Upload Materials
                  <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                  </svg>
                </a>
              </div>
            </div>

            <!-- Announcements Card -->
            <div class="bg-white rounded-xl shadow overflow-hidden">
              <div class="p-5">
                <div class="flex items-center mb-4">
                  <div class="flex-shrink-0 bg-purple-100 rounded-md p-2">
                    <svg class="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"></path>
                    </svg>
                  </div>
                  <h3 class="ml-3 text-lg font-semibold text-gray-900">Announcements</h3>
                </div>
                <p class="text-sm text-gray-600 mb-4">Create announcements and updates for your classes</p>
                <a href="announcements.php" class="text-purple-600 hover:text-purple-800 text-sm font-medium flex items-center">
                  Make Announcement
                  <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                  </svg>
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </main>

<script>
  // Simple search functionality for subjects
  document.getElementById('search-subjects').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.subject-row');
    
    rows.forEach(row => {
      const subject = row.getAttribute('data-subject').toLowerCase();
      if (subject.includes(searchTerm)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
</script>

<?php include("../public/footer.php") ?>