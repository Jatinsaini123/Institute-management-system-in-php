<?php include("../public/header.php") ?>
<?php include("../includes/config.php") ?>

<div class="flex overflow-hidden bg-white pt-16">

<!-- Sidebar -->
<?php include("sidebar.php") ?>

<div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

<div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
  <main>
    <div class="pt-8 px-6">
      <!-- Main Container -->
      <div class="max-w-5xl mx-auto">
        
        <!-- Header Section with Tabs -->
        <div class="mb-8">
          <h1 class="text-2xl font-bold text-gray-900 mb-2">Course Materials</h1>
          <p class="text-sm text-gray-600 mb-4">Share learning resources with your students</p>
          
          <!-- Navigation Tabs -->
          <div class="border-b border-gray-200">
            <nav class="-mb-px flex space-x-8">
              <button id="tab-upload" class="tab-btn border-blue-500 text-blue-600 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm">
                Upload New Material
              </button>
              <button id="tab-materials" class="tab-btn border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm">
                My Materials
              </button>
            </nav>
          </div>
        </div>
        
        <!-- Content Sections -->
        <div id="content-upload" class="tab-content">
          <!-- Upload Form Card -->
          <div class="bg-white shadow rounded-xl overflow-hidden">
            <div class="p-6">
              <form action="process_upload.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Select Class</label>
                    <select name="class_id" required class="w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500">
                      <option value="">Choose a class</option>
                      <?php
                      // Fetch classes for the logged-in teacher
                      $teacher_email = $_SESSION['teacheremail'];
                      $class_query = "SELECT class_id, class_name FROM classes WHERE teacher_email = ?";
                      $stmt = $db_conn->prepare($class_query);
                      $stmt->bind_param("s", $teacher_email);
                      $stmt->execute();
                      $result = $stmt->get_result();

                      while ($class = $result->fetch_assoc()) {
                        echo "<option value='{$class['class_id']}'>{$class['class_name']}</option>";
                      }
                      ?>
                    </select>
                  </div>

                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Material Type</label>
                    <select name="material_type" required class="w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500">
                      <option value="notes">Notes</option>
                      <option value="assignment">Assignment</option>
                      <option value="presentation">Presentation</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input type="text" name="title" required 
                    class="w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter material title">
                </div>

                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea name="description" rows="3" 
                    class="w-full border border-gray-300 rounded-md p-2.5 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter material description"></textarea>
                </div>

                <div class="bg-gray-50 p-4 rounded-lg">
                  <label class="block text-sm font-medium text-gray-700 mb-3">Upload File</label>
                  <div class="flex items-center justify-center">
                    <label for="dropzone-file" class="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                      <div class="flex flex-col items-center justify-center pt-5 pb-6">
                        <svg class="w-10 h-10 mb-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
                        <p class="mb-2 text-sm text-gray-500"><span class="font-semibold">Click to upload</span> or drag and drop</p>
                        <p class="text-xs text-gray-500">PDF, DOC, DOCX, PPT, PPTX (MAX. 10MB)</p>
                      </div>
                      <input id="dropzone-file" name="material_file" type="file" class="hidden" required />
                    </label>
                  </div>
                  <div id="file-name" class="mt-2 text-sm text-gray-500"></div>
                </div>

                <div class="flex justify-end">
                  <button type="submit" 
                    class="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-500 text-white rounded-md hover:from-blue-700 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 shadow-md transition-all duration-150">
                    Upload Material
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div id="content-materials" class="tab-content hidden">
          <!-- Filter and Search -->
          <div class="bg-white shadow rounded-xl p-6 mb-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div class="flex-1">
                <label for="search" class="sr-only">Search</label>
                <div class="relative">
                  <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                  </div>
                  <input type="search" id="search" class="block w-full p-2.5 pl-10 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500" placeholder="Search by title...">
                </div>
              </div>
              <div class="flex items-center space-x-3">
                <select id="type-filter" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5">
                  <option value="all">All Types</option>
                  <option value="notes">Notes</option>
                  <option value="assignment">Assignments</option>
                  <option value="presentation">Presentations</option>
                  <option value="other">Other</option>
                </select>
                <button id="view-grid" class="p-2 text-gray-500 rounded-lg hover:bg-gray-100">
                  <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                </button>
                <button id="view-list" class="p-2 text-blue-600 bg-gray-100 rounded-lg">
                  <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg>
                </button>
              </div>
            </div>
          </div>

          <!-- Materials List View -->
          <div id="materials-list" class="bg-white shadow rounded-xl overflow-hidden">
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Material</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  <?php
                  // Fetch all materials for the teacher
                  $all_materials_query = "SELECT m.*, c.class_name 
                                        FROM materials m 
                                        JOIN classes c ON m.class_id = c.class_id 
                                        WHERE m.uploaded_by = ? 
                                        ORDER BY m.upload_date DESC";
                  $stmt = $db_conn->prepare($all_materials_query);
                  $stmt->bind_param("s", $teacher_email);
                  $stmt->execute();
                  $all_materials_result = $stmt->get_result();
                  
                  if ($all_materials_result->num_rows === 0) {
                    echo '<tr><td colspan="5" class="px-6 py-10 text-center text-gray-500">No materials uploaded yet</td></tr>';
                  }

                  while ($material = $all_materials_result->fetch_assoc()) {
                    // Determine file icon
                    $fileType = pathinfo($material['file_path'], PATHINFO_EXTENSION);
                    $typeColor = '';
                    
                    if (in_array($fileType, ['pdf'])) {
                      $typeColor = 'text-red-600 bg-red-100';
                    } elseif (in_array($fileType, ['doc', 'docx'])) {
                      $typeColor = 'text-blue-600 bg-blue-100';
                    } elseif (in_array($fileType, ['ppt', 'pptx'])) {
                      $typeColor = 'text-orange-600 bg-orange-100';
                    } else {
                      $typeColor = 'text-gray-600 bg-gray-100';
                    }
                    
                    echo "<tr class='hover:bg-gray-50'>
                      <td class='px-6 py-4 whitespace-nowrap'>
                        <div class='flex items-center'>
                          <div class='flex-shrink-0 h-10 w-10 {$typeColor} rounded-lg flex items-center justify-center'>
                            " . strtoupper(substr($fileType, 0, 3)) . "
                          </div>
                          <div class='ml-4'>
                            <div class='text-sm font-medium text-gray-900'>{$material['title']}</div>
                            <div class='text-sm text-gray-500 truncate max-w-xs'>{$material['description']}</div>
                          </div>
                        </div>
                      </td>
                      <td class='px-6 py-4 whitespace-nowrap'>
                        <span class='px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800'>
                          {$material['material_type']}
                        </span>
                      </td>
                      <td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>{$material['class_name']}</td>
                      <td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . date('M j, Y', strtotime($material['upload_date'])) . "</td>
                      <td class='px-6 py-4 whitespace-nowrap text-sm font-medium'>
                        <div class='flex space-x-2'>
                          <a href='{$material['file_path']}' target='_blank' class='text-indigo-600 hover:text-indigo-900'>View</a>
                          <a href='delete_material.php?id={$material['id']}' class='text-red-600 hover:text-red-900' onclick='return confirm(\"Are you sure you want to delete this material?\");'>Delete</a>
                        </div>
                      </td>
                    </tr>";
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Materials Grid View (Hidden by Default) -->
          <div id="materials-grid" class="hidden grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php
            // Reset result pointer
            if ($all_materials_result->num_rows > 0) {
              $all_materials_result->data_seek(0);
              
              while ($material = $all_materials_result->fetch_assoc()) {
                // Determine card color based on material type
                $cardColor = '';
                switch($material['material_type']) {
                  case 'notes': $cardColor = 'border-blue-200 bg-blue-50'; break;
                  case 'assignment': $cardColor = 'border-green-200 bg-green-50'; break;
                  case 'presentation': $cardColor = 'border-orange-200 bg-orange-50'; break;
                  default: $cardColor = 'border-gray-200 bg-gray-50';
                }
                
                echo "
                <div class='material-card {$cardColor} border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow'>
                  <div class='p-5'>
                    <div class='flex justify-between items-start'>
                      <h3 class='text-lg font-semibold text-gray-900 mb-1'>{$material['title']}</h3>
                      <span class='text-xs font-medium px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-800'>
                        {$material['material_type']}
                      </span>
                    </div>
                    <p class='text-sm text-gray-600 mb-4'>{$material['description']}</p>
                    <div class='flex justify-between items-center text-sm'>
                      <span class='text-gray-500'>{$material['class_name']}</span>
                      <span class='text-gray-400'>" . date('M j, Y', strtotime($material['upload_date'])) . "</span>
                    </div>
                  </div>
                  <div class='border-t border-gray-200 bg-white px-5 py-3 flex justify-between'>
                    <a href='{$material['file_path']}' target='_blank' class='text-sm text-blue-600 hover:text-blue-800 font-medium'>Preview</a>
                    <a href='delete_material.php?id={$material['id']}' onclick='return confirm(\"Are you sure?\");' class='text-sm text-red-600 hover:text-red-800 font-medium'>Delete</a>
                  </div>
                </div>";
              }
            } else {
              echo '<div class="col-span-full py-12 text-center text-gray-500">No materials uploaded yet</div>';
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>

<?php include("../public/footer.php") ?>

<script>
  // Tab switching
  const tabUpload = document.getElementById('tab-upload');
  const tabMaterials = document.getElementById('tab-materials');
  const contentUpload = document.getElementById('content-upload');
  const contentMaterials = document.getElementById('content-materials');
  
  tabUpload.addEventListener('click', function() {
    tabUpload.classList.add('border-blue-500', 'text-blue-600');
    tabUpload.classList.remove('border-transparent', 'text-gray-500');
    tabMaterials.classList.add('border-transparent', 'text-gray-500');
    tabMaterials.classList.remove('border-blue-500', 'text-blue-600');
    
    contentUpload.classList.remove('hidden');
    contentMaterials.classList.add('hidden');
  });
  
  tabMaterials.addEventListener('click', function() {
    tabMaterials.classList.add('border-blue-500', 'text-blue-600');
    tabMaterials.classList.remove('border-transparent', 'text-gray-500');
    tabUpload.classList.add('border-transparent', 'text-gray-500');
    tabUpload.classList.remove('border-blue-500', 'text-blue-600');
    
    contentMaterials.classList.remove('hidden');
    contentUpload.classList.add('hidden');
  });
  
  // View switching
  const viewGrid = document.getElementById('view-grid');
  const viewList = document.getElementById('view-list');
  const materialsList = document.getElementById('materials-list');
  const materialsGrid = document.getElementById('materials-grid');
  
  viewGrid.addEventListener('click', function() {
    viewGrid.classList.add('text-blue-600', 'bg-gray-100');
    viewGrid.classList.remove('text-gray-500');
    viewList.classList.add('text-gray-500');
    viewList.classList.remove('text-blue-600', 'bg-gray-100');
    
    materialsGrid.classList.remove('hidden');
    materialsList.classList.add('hidden');
  });
  
  viewList.addEventListener('click', function() {
    viewList.classList.add('text-blue-600', 'bg-gray-100');
    viewList.classList.remove('text-gray-500');
    viewGrid.classList.add('text-gray-500');
    viewGrid.classList.remove('text-blue-600', 'bg-gray-100');
    
    materialsList.classList.remove('hidden');
    materialsGrid.classList.add('hidden');
  });
  
  // File upload display
  const dropzoneFile = document.getElementById('dropzone-file');
  const fileName = document.getElementById('file-name');
  
  dropzoneFile.addEventListener('change', function(e) {
    if (e.target.files[0]) {
      fileName.textContent = `Selected file: ${e.target.files[0].name}`;
    } else {
      fileName.textContent = '';
    }
  });
  
  // Search and filter functionality
  const search = document.getElementById('search');
  const typeFilter = document.getElementById('type-filter');
  const materialCards = document.querySelectorAll('.material-card');
  const tableRows = document.querySelectorAll('tbody tr');
  
  function filterMaterials() {
    const searchValue = search.value.toLowerCase();
    const typeValue = typeFilter.value.toLowerCase();
    
    // Filter table rows
    tableRows.forEach(row => {
      const title = row.querySelector('td:first-child .text-gray-900').textContent.toLowerCase();
      const type = row.querySelector('td:nth-child(2) span').textContent.toLowerCase();
      
      const matchesSearch = title.includes(searchValue);
      const matchesType = typeValue === 'all' || type === typeValue;
      
      row.classList.toggle('hidden', !(matchesSearch && matchesType));
    });
    
    // Filter grid cards
    materialCards.forEach(card => {
      const title = card.querySelector('h3').textContent.toLowerCase();
      const type = card.querySelector('span').textContent.toLowerCase();
      
      const matchesSearch = title.includes(searchValue);
      const matchesType = typeValue === 'all' || type === typeValue;
      
      card.classList.toggle('hidden', !(matchesSearch && matchesType));
    });
  }
  
  search.addEventListener('input', filterMaterials);
  typeFilter.addEventListener('change', filterMaterials);
</script> 