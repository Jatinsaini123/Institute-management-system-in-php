<?php
session_start();
// Sample session data, replace with actual DB call if needed
$_SESSION['teacher_name'] = $_SESSION['teacher_name'] ?? "Mr. John Doe";
$_SESSION['teacher_email'] = $_SESSION['teacher_email'] ?? "johndoe@example.com";
$_SESSION['teacher_subject'] = $_SESSION['teacher_subject'] ?? "Mathematics";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Teacher Profile</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

  <!-- Header -->
  <header class="bg-white shadow-md py-4 px-6 flex justify-between items-center">
    <h1 class="text-xl font-bold text-gray-800">Teacher Panel</h1>
    <a href="dashboard.php" class="text-blue-500 hover:underline">Back to Dashboard</a>
  </header>

  <!-- Profile Card -->
  <main class="flex justify-center mt-10">
    <div class="bg-white rounded-lg shadow-md p-8 w-full max-w-xl">
      <div class="flex items-center justify-center mb-6">
        <img src="https://img.freepik.com/free-icon/user_318-563642.jpg?w=360" class="w-24 h-24 rounded-full border-4 border-blue-500" alt="Teacher Profile Picture">
      </div>

      <h2 class="text-center text-2xl font-semibold text-gray-700 mb-2">
        <?php echo $_SESSION['teacher_name']; ?>
      </h2>

      <p class="text-center text-gray-500 mb-6"><?php echo $_SESSION['teacher_email']; ?></p>

      <div class="space-y-4">
        <div class="flex justify-between border-b pb-2">
          <span class="text-gray-600 font-medium">Name:</span>
          <span class="text-gray-800"><?php echo $_SESSION['teacher_name']; ?></span>
        </div>
        <div class="flex justify-between border-b pb-2">
          <span class="text-gray-600 font-medium">Email:</span>
          <span class="text-gray-800"><?php echo $_SESSION['teacher_email']; ?></span>
        </div>
        <div class="flex justify-between border-b pb-2">
          <span class="text-gray-600 font-medium">Subject:</span>
          <span class="text-gray-800"><?php echo $_SESSION['teacher_subject']; ?></span>
        </div>
      </div>

      <div class="mt-6 text-center">
        <a href="edit-profile.php" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition duration-200">Edit Profile</a>
      </div>
    </div>
  </main>

</body>
</html>
