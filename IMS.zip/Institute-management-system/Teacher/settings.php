<?php 
include("../actions/checkteacher.php");
include("../public/header.php");
include("../includes/config.php");
?>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main>
            <div class="py-8 px-6">
                <div class="max-w-6xl mx-auto">
                    <!-- Header Section -->
                    <div class="mb-6">
                        <h1 class="text-2xl font-bold text-gray-900 mb-2">Account Settings</h1>
                        <p class="text-sm text-gray-600">Manage your account preferences and settings</p>
                    </div>

                    <!-- Main Content Area -->
                    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        <!-- Settings Navigation - Left Side -->
                        <div class="lg:col-span-3">
                            <div class="bg-white shadow rounded-xl overflow-hidden">
                                <nav class="space-y-1" aria-label="Settings">
                                    <a href="#profile" class="settings-nav-item flex items-center px-4 py-3 text-sm font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 border-l-4 border-blue-600" data-target="profile-section">
                                        <svg class="mr-3 h-5 w-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                        </svg>
                                        Profile Settings
                                    </a>

                                    <a href="#password" class="settings-nav-item flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 border-l-4 border-transparent" data-target="password-section">
                                        <svg class="mr-3 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                        </svg>
                                        Change Password
                                    </a>

                                    <a href="#notification" class="settings-nav-item flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 border-l-4 border-transparent" data-target="notification-section">
                                        <svg class="mr-3 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                                        </svg>
                                        Notification Preferences
                                    </a>

                                    <a href="#appearance" class="settings-nav-item flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 border-l-4 border-transparent" data-target="appearance-section">
                                        <svg class="mr-3 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"></path>
                                        </svg>
                                        Appearance
                                    </a>

                                    <a href="#security" class="settings-nav-item flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 border-l-4 border-transparent" data-target="security-section">
                                        <svg class="mr-3 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                                        </svg>
                                        Security
                                    </a>
                                </nav>
                            </div>
                        </div>
                        
                        <!-- Settings Content - Right Side -->
                        <div class="lg:col-span-9">
                            <?php
                            // Get teacher's info
                            $email = $_SESSION['useremail'];
                            $query = "SELECT u.id, u.firstname, u.lastname, u.email, u.phone, t.qualification, t.experience, t.bio, t.joining_date 
                                     FROM user u 
                                     JOIN teacher t ON u.id = t.id 
                                     WHERE u.email = '$email'";
                            $result = mysqli_query($db_conn, $query);
                            $teacher = mysqli_fetch_object($result);
                            ?>

                            <!-- Profile Settings Section -->
                            <div id="profile-section" class="settings-section bg-white shadow rounded-xl overflow-hidden">
                                <div class="px-6 py-4 border-b border-gray-100">
                                    <h2 class="text-lg font-semibold text-gray-900">Profile Settings</h2>
                                    <p class="text-sm text-gray-500 mt-1">Update your personal information</p>
                                </div>
                                
                                <div class="p-6">
                                    <form action="../actions/update_profile.php" method="POST" class="space-y-6">
                                        <input type="hidden" name="user_id" value="<?php echo $teacher->id; ?>">
                                        
                                        <!-- Profile Photo -->
                                        <div class="flex items-center space-x-6">
                                            <div class="flex-shrink-0">
                                                <div class="relative">
                                                    <img class="h-24 w-24 rounded-full border-4 border-white shadow" src="https://img.freepik.com/free-icon/user_318-563642.jpg?w=360" alt="Profile Photo">
                                                    <span class="absolute bottom-0 right-0 h-6 w-6 rounded-full bg-green-500 border-2 border-white"></span>
                                                </div>
                                            </div>
                                            <div>
                                                <button type="button" class="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-100 rounded-md hover:bg-blue-200">
                                                    Change photo
                                                </button>
                                                <p class="mt-1 text-xs text-gray-500">JPG, GIF or PNG. 1MB max.</p>
                                            </div>
                                        </div>
                                        
                                        <!-- Name Fields -->
                                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div>
                                                <label for="firstname" class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                                                <input type="text" name="firstname" id="firstname" value="<?php echo $teacher->firstname; ?>" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            </div>
                                            <div>
                                                <label for="lastname" class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                                                <input type="text" name="lastname" id="lastname" value="<?php echo $teacher->lastname; ?>" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            </div>
                                        </div>
                                        
                                        <!-- Contact Information -->
                                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div>
                                                <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                                                <input type="email" name="email" id="email" value="<?php echo $teacher->email; ?>" class="block w-full rounded-md border-gray-300 bg-gray-100 shadow-sm focus:border-blue-500 focus:ring-blue-500" readonly>
                                            </div>
                                            <div>
                                                <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                                                <input type="text" name="phone" id="phone" value="<?php echo $teacher->phone; ?>" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            </div>
                                        </div>
                                        
                                        <!-- Professional Information -->
                                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div>
                                                <label for="qualification" class="block text-sm font-medium text-gray-700 mb-1">Qualification</label>
                                                <input type="text" name="qualification" id="qualification" value="<?php echo $teacher->qualification; ?>" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            </div>
                                            <div>
                                                <label for="experience" class="block text-sm font-medium text-gray-700 mb-1">Experience (years)</label>
                                                <input type="number" name="experience" id="experience" value="<?php echo $teacher->experience; ?>" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            </div>
                                        </div>
                                        
                                        <!-- Bio -->
                                        <div>
                                            <label for="bio" class="block text-sm font-medium text-gray-700 mb-1">Professional Bio</label>
                                            <textarea name="bio" id="bio" rows="4" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"><?php echo $teacher->bio; ?></textarea>
                                            <p class="mt-1 text-xs text-gray-500">Brief description for your profile. URLs are hyperlinked.</p>
                                        </div>
                                        
                                        <!-- Save Button -->
                                        <div class="flex justify-end">
                                            <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                Save Changes
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Password Section -->
                            <div id="password-section" class="settings-section bg-white shadow rounded-xl overflow-hidden hidden">
                                <div class="px-6 py-4 border-b border-gray-100">
                                    <h2 class="text-lg font-semibold text-gray-900">Change Password</h2>
                                    <p class="text-sm text-gray-500 mt-1">Ensure your account is using a strong password</p>
                                </div>
                                
                                <div class="p-6">
                                    <form action="../actions/change_password.php" method="POST" class="space-y-6">
                                        <input type="hidden" name="user_id" value="<?php echo $teacher->id; ?>">
                                        
                                        <div>
                                            <label for="current_password" class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                                            <input type="password" name="current_password" id="current_password" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" required>
                                        </div>
                                        
                                        <div>
                                            <label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                                            <input type="password" name="new_password" id="new_password" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" required>
                                        </div>
                                        
                                        <div>
                                            <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                                            <input type="password" name="confirm_password" id="confirm_password" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" required>
                                        </div>
                                        
                                        <div>
                                            <h3 class="text-sm font-medium text-gray-700 mb-2">Password Requirements:</h3>
                                            <ul class="list-disc pl-5 text-xs text-gray-500 space-y-1">
                                                <li>Minimum 8 characters long</li>
                                                <li>Include at least one uppercase letter</li>
                                                <li>Include at least one number</li>
                                                <li>Include at least one special character</li>
                                            </ul>
                                        </div>
                                        
                                        <!-- Save Button -->
                                        <div class="flex justify-end">
                                            <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                Update Password
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Notification Preferences Section -->
                            <div id="notification-section" class="settings-section bg-white shadow rounded-xl overflow-hidden hidden">
                                <div class="px-6 py-4 border-b border-gray-100">
                                    <h2 class="text-lg font-semibold text-gray-900">Notification Preferences</h2>
                                    <p class="text-sm text-gray-500 mt-1">Manage how you receive notifications</p>
                                </div>
                                
                                <div class="p-6">
                                    <form action="../actions/update_notifications.php" method="POST" class="space-y-6">
                                        <input type="hidden" name="user_id" value="<?php echo $teacher->id; ?>">
                                        
                                        <div class="space-y-4">
                                            <h3 class="text-sm font-medium text-gray-700">Email Notifications</h3>
                                            
                                            <div class="flex items-center justify-between py-3 border-b border-gray-100">
                                                <div>
                                                    <p class="text-sm font-medium text-gray-900">Student Submissions</p>
                                                    <p class="text-xs text-gray-500">Get notified when a student submits an assignment</p>
                                                </div>
                                                <label class="relative inline-flex items-center cursor-pointer">
                                                    <input type="checkbox" name="email_submissions" class="sr-only peer" checked>
                                                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                                </label>
                                            </div>
                                            
                                            <div class="flex items-center justify-between py-3 border-b border-gray-100">
                                                <div>
                                                    <p class="text-sm font-medium text-gray-900">Messages</p>
                                                    <p class="text-xs text-gray-500">Get notified when you receive a message</p>
                                                </div>
                                                <label class="relative inline-flex items-center cursor-pointer">
                                                    <input type="checkbox" name="email_messages" class="sr-only peer" checked>
                                                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                                </label>
                                            </div>
                                            
                                            <div class="flex items-center justify-between py-3 border-b border-gray-100">
                                                <div>
                                                    <p class="text-sm font-medium text-gray-900">Reminders</p>
                                                    <p class="text-xs text-gray-500">Get notified about upcoming events and deadlines</p>
                                                </div>
                                                <label class="relative inline-flex items-center cursor-pointer">
                                                    <input type="checkbox" name="email_reminders" class="sr-only peer" checked>
                                                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                                </label>
                                            </div>
                                            
                                            <div class="flex items-center justify-between py-3">
                                                <div>
                                                    <p class="text-sm font-medium text-gray-900">Administrative Announcements</p>
                                                    <p class="text-xs text-gray-500">Updates from administrators</p>
                                                </div>
                                                <label class="relative inline-flex items-center cursor-pointer">
                                                    <input type="checkbox" name="email_announcements" class="sr-only peer" checked>
                                                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                                </label>
                                            </div>
                                        </div>
                                        
                                        <div class="pt-4">
                                            <h3 class="text-sm font-medium text-gray-700 mb-3">Notification Frequency</h3>
                                            
                                            <div class="space-y-2">
                                                <div class="flex items-center">
                                                    <input id="push-everything" name="notification_frequency" type="radio" value="immediately" class="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500" checked>
                                                    <label for="push-everything" class="ml-3 block text-sm font-medium text-gray-700">Send immediately</label>
                                                </div>
                                                <div class="flex items-center">
                                                    <input id="push-daily" name="notification_frequency" type="radio" value="daily" class="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500">
                                                    <label for="push-daily" class="ml-3 block text-sm font-medium text-gray-700">Daily digest</label>
                                                </div>
                                                <div class="flex items-center">
                                                    <input id="push-weekly" name="notification_frequency" type="radio" value="weekly" class="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500">
                                                    <label for="push-weekly" class="ml-3 block text-sm font-medium text-gray-700">Weekly digest</label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Save Button -->
                                        <div class="flex justify-end">
                                            <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                Save Preferences
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Appearance Section -->
                            <div id="appearance-section" class="settings-section bg-white shadow rounded-xl overflow-hidden hidden">
                                <div class="px-6 py-4 border-b border-gray-100">
                                    <h2 class="text-lg font-semibold text-gray-900">Appearance</h2>
                                    <p class="text-sm text-gray-500 mt-1">Customize how the application looks</p>
                                </div>
                                
                                <div class="p-6">
                                    <form action="../actions/update_appearance.php" method="POST" class="space-y-6">
                                        <input type="hidden" name="user_id" value="<?php echo $teacher->id; ?>">
                                        
                                        <!-- Theme Selection -->
                                        <div>
                                            <h3 class="text-sm font-medium text-gray-700 mb-3">Theme</h3>
                                            <div class="grid grid-cols-3 gap-3">
                                                <label class="flex flex-col bg-white rounded-lg border border-gray-300 cursor-pointer hover:border-blue-500 px-2 py-2 relative">
                                                    <span class="block h-12 w-full bg-white rounded border-b border-gray-300 mb-2"></span>
                                                    <span class="flex items-center justify-between">
                                                        <span class="text-xs font-medium text-gray-900">Light</span>
                                                        <input type="radio" name="theme" value="light" class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked>
                                                    </span>
                                                </label>
                                                
                                                <label class="flex flex-col bg-white rounded-lg border border-gray-300 cursor-pointer hover:border-blue-500 px-2 py-2">
                                                    <span class="block h-12 w-full bg-gray-800 rounded border-b border-gray-700 mb-2"></span>
                                                    <span class="flex items-center justify-between">
                                                        <span class="text-xs font-medium text-gray-900">Dark</span>
                                                        <input type="radio" name="theme" value="dark" class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500">
                                                    </span>
                                                </label>
                                                
                                                <label class="flex flex-col bg-white rounded-lg border border-gray-300 cursor-pointer hover:border-blue-500 px-2 py-2">
                                                    <span class="block h-12 w-full bg-gradient-to-r from-white to-gray-800 rounded border-b border-gray-300 mb-2"></span>
                                                    <span class="flex items-center justify-between">
                                                        <span class="text-xs font-medium text-gray-900">System</span>
                                                        <input type="radio" name="theme" value="system" class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500">
                                                    </span>
                                                </label>
                                            </div>
                                        </div>
                                        
                                        <!-- Color Scheme -->
                                        <div>
                                            <h3 class="text-sm font-medium text-gray-700 mb-3">Accent Color</h3>
                                            <div class="grid grid-cols-6 gap-3">
                                                <label class="cursor-pointer flex items-center justify-center">
                                                    <input type="radio" name="color" value="blue" class="sr-only peer" checked>
                                                    <span class="h-8 w-8 bg-blue-600 rounded-full peer-checked:ring-2 peer-checked:ring-offset-2 peer-checked:ring-blue-600"></span>
                                                </label>
                                                
                                                <label class="cursor-pointer flex items-center justify-center">
                                                    <input type="radio" name="color" value="green" class="sr-only peer">
                                                    <span class="h-8 w-8 bg-green-600 rounded-full peer-checked:ring-2 peer-checked:ring-offset-2 peer-checked:ring-green-600"></span>
                                                </label>
                                                
                                                <label class="cursor-pointer flex items-center justify-center">
                                                    <input type="radio" name="color" value="purple" class="sr-only peer">
                                                    <span class="h-8 w-8 bg-purple-600 rounded-full peer-checked:ring-2 peer-checked:ring-offset-2 peer-checked:ring-purple-600"></span>
                                                </label>
                                                
                                                <label class="cursor-pointer flex items-center justify-center">
                                                    <input type="radio" name="color" value="red" class="sr-only peer">
                                                    <span class="h-8 w-8 bg-red-600 rounded-full peer-checked:ring-2 peer-checked:ring-offset-2 peer-checked:ring-red-600"></span>
                                                </label>
                                                
                                                <label class="cursor-pointer flex items-center justify-center">
                                                    <input type="radio" name="color" value="orange" class="sr-only peer">
                                                    <span class="h-8 w-8 bg-orange-500 rounded-full peer-checked:ring-2