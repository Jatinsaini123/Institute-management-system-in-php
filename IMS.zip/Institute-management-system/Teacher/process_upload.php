<?php
session_start();
include("../includes/config.php");

// Check if teacher is logged in
if (!isset($_SESSION['teacheremail'])) {
    header("Location: ../Login/login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $class_id = $_POST['class_id'];
    $material_type = $_POST['material_type'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $teacher_email = $_SESSION['teacheremail'];
    $upload_date = date('Y-m-d H:i:s');

    // Handle file upload
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($_FILES["material_file"]["name"]);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check file size
    if ($_FILES["material_file"]["size"] > 10000000) {
        $_SESSION['error_message'] = "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if (!in_array($fileType, ['pdf', 'doc', 'docx', 'ppt', 'pptx'])) {
        $_SESSION['error_message'] = "Sorry, only PDF, DOC, DOCX, PPT, and PPTX files are allowed.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        $_SESSION['error_message'] = "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["material_file"]["tmp_name"], $target_file)) {
            // Insert into database
            $sql = "INSERT INTO materials (class_id, material_type, title, description, file_path, uploaded_by, upload_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db_conn->prepare($sql);
            $stmt->bind_param("sssssss", $class_id, $material_type, $title, $description, $target_file, $teacher_email, $upload_date);

            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Material uploaded successfully!";
            } else {
                $_SESSION['error_message'] = "Error uploading material. Please try again.";
            }
        } else {
            $_SESSION['error_message'] = "Sorry, there was an error uploading your file.";
        }
    }

    header("Location: upload-materials.php");
    exit();
}
?> 