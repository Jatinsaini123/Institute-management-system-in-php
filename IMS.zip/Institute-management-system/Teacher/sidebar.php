<style>
/* Add Scrollbar Styles */
.sidebar-scroll {
    height: calc(100vh - 280px);
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #3b82f6 transparent;
}

.sidebar-scroll::-webkit-scrollbar {
    width: 4px;
}

.sidebar-scroll::-webkit-scrollbar-track {
    background: transparent;
}

.sidebar-scroll::-webkit-scrollbar-thumb {
    background-color: #3b82f6;
    border-radius: 10px;
}

.sidebar-scroll::-webkit-scrollbar-thumb:hover {
    background-color: #2563eb;
}
</style>

<aside id="sidebar" class="sidebar-container ml-[-100%] fixed z-10 top-0 pb-3 px-3 w-full flex flex-col justify-between h-screen border-r bg-white transition duration-300 md:w-4/12 lg:ml-0 lg:w-[25%] xl:w-[20%] 2xl:w-[13.5%]" aria-label="Sidebar">
    <!-- Header -->
    <div>
        <div class="-mx-6 px-6 py-4">
            <a href="index.php">
                <img src="../assets/images/logo.png" class="w-32" alt="IMS logo"/>
            </a>
        </div>

        <!-- Profile Section -->
        <div class="mt-8 text-center relative profile-section">
            <div class="relative inline-block">
                <img src="https://img.freepik.com/free-icon/user_318-563642.jpg?w=360" alt="Teacher Profile" class="w-10 h-10 m-auto rounded-full object-cover lg:w-28 lg:h-28 border-2 border-blue-500 p-1"/>
                <span class="absolute bottom-0 right-0 bg-green-500 w-4 h-4 rounded-full border-2 border-white"></span>
            </div>
            <h5 class="hidden mt-4 text-xl font-semibold text-gray-600 lg:block">Teacher Panel</h5>
            <span class="hidden text-gray-400 lg:block"><?php echo $_SESSION['useremail'] ?? ''; ?></span>
            <div class="profile-dropdown">
                <div class="p-4 border-b">
                    <a href="profile.php" class="flex items-center space-x-3 hover:bg-gray-50 p-2 rounded-md">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10 12a4 4 0 100-8 4 4 0 000 8z"></path>
                            <path fill-rule="evenodd" d="M3 10a7 7 0 1114 0 7 7 0 01-14 0zm7-5a5 5 0 100 10 5 5 0 000-10z"></path>
                        </svg>
                        <span>View Profile</span>
                    </a>
                    <a href="edit-profile.php" class="flex items-center space-x-3 hover:bg-gray-50 p-2 rounded-md">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z"></path>
                            <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"></path>
                        </svg>
                        <span>Edit Profile</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Scrollable Menu -->
        <div class="sidebar-scroll">
            <ul class="space-y-2 tracking-wide mt-8">

                <li>
                    <a href="index.php" class="menu-item relative px-4 py-3 flex items-center space-x-4 rounded-xl text-white bg-gradient-to-r from-sky-600 to-cyan-400">
                        <svg class="-ml-1 h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path d="M3 12l2-2m0 0l7-7 7 7M13 5v6h6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span class="-mr-1 font-medium">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="manage-classes.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor">
                            <path d="M8 16V4h8v12M3 20h18" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span class="group-hover:text-gray-700">Subjects</span>
                    </a>
                </li>

                <li>
                    <a href="attendance.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor">
                            <path d="M5 13l4 4L19 7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span class="group-hover:text-gray-700">Take Attendance</span>
                    </a>
                </li>

                <li>
                    <a href="assign-grades.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor">
                            <path d="M12 20l9-5-9-5-9 5 9 5zM12 12l9-5-9-5-9 5 9 5z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span class="group-hover:text-gray-700">Assign Grades</span>
                    </a>
                </li>

                <li>
                    <a href="upload-materials.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor">
                            <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M4 12l8-8 8 8M12 4v12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span class="group-hover:text-gray-700">Upload Materials</span>
                    </a>
                </li>

                <li>
                    <a href="announcements.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor">
                            <path d="M5 13l4 4L19 7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span class="group-hover:text-gray-700">Announcements</span>
                    </a>
                </li>
                <li>
    <a href="settings.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
        <svg class="w-5 h-5" fill="none" stroke="currentColor">
            <path d="M12 4v16m8-8H4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="group-hover:text-gray-700">Settings</span>
    </a>
</li>

<li>
    <a href="reports.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
        <svg class="w-5 h-5" fill="none" stroke="currentColor">
            <path d="M9 17v-6h13m-7 7V5a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2h7a2 2 0 002-2z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="group-hover:text-gray-700">Reports</span>
    </a>
</li>

<li>
    <a href="messages.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
        <svg class="w-5 h-5" fill="none" stroke="currentColor">
            <path d="M8 10h.01M12 10h.01M16 10h.01M21 16V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2h14a2 2 0 002-2z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="group-hover:text-gray-700">Messages</span>
    </a>
</li>

<li>
    <a href="calendar.php" class="menu-item px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
        <svg class="w-5 h-5" fill="none" stroke="currentColor">
            <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="group-hover:text-gray-700">Calendar</span>
    </a>
</li>

            </ul>

           
        </div>

    </div>
    <div class="mt-auto px-6 py-4 border-t">
        <form action="../login/login.php" method="post">
            <button type="submit" class="logout-btn w-full flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                <span>Sign Out</span>
            </button>
        </form>
    </div>
</aside>
