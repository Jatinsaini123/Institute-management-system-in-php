<?php 
include("../actions/checkteacher.php");
include("../public/header.php");
include("../includes/config.php");
?>

<div class="flex overflow-hidden bg-white">
    <?php include("sidebar.php")?>

    <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main class="p-6">
            <div class="mb-6">
                <h1 class="text-2xl font-semibold text-gray-900">Student Marks Assignment</h1>
            </div>

            <!-- Selection Form -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <form action="" method="POST" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <!-- Year Selection -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Year</label>
                            <select name="year" required class="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">Select Year</option>
                                <?php
                                $years = mysqli_query($db_conn, "SELECT * FROM years");
                                while ($year = mysqli_fetch_object($years)) {
                                    echo "<option value='{$year->id}'>{$year->year}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Department Selection -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Department</label>
                            <select name="dept" required class="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">Select Department</option>
                                <?php
                                $departments = mysqli_query($db_conn, "SELECT * FROM department");
                                while ($dept = mysqli_fetch_object($departments)) {
                                    echo "<option value='{$dept->id}'>" . ucfirst($dept->name) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Section Selection -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Section</label>
                            <select name="sec" required class="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">Select Section</option>
                                <?php
                                $sections = mysqli_query($db_conn, "SELECT * FROM section");
                                while ($section = mysqli_fetch_object($sections)) {
                                    echo "<option value='{$section->id}'>" . ucfirst($section->name) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Exam Selection -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Exam</label>
                            <select name="exam" required class="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">Select Exam</option>
                                <?php
                                $exams = mysqli_query($db_conn, "SELECT * FROM exam");
                                while ($exam = mysqli_fetch_object($exams)) {
                                    echo "<option value='{$exam->id}'>" . ucfirst($exam->examname) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" name="assignmarks" 
                                class="px-6 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-300">
                            Show Students
                        </button>
                    </div>
                </form>
            </div>

            <?php if(isset($_POST['assignmarks'])): 
                // Get teacher's subject and verify allocation
                $email = $_SESSION['useremail'];
                $year = $_POST['year'];
                $dept = $_POST['dept'];
                $sec = $_POST['sec'];
                $exam = $_POST['exam'];

                // Get teacher's subject allocation
                $query = "SELECT a.subjectid, s.name as subject_name, e.totalmarks, e.examname 
                         FROM allotment a 
                         JOIN subject s ON a.subjectid = s.id 
                         JOIN exam e ON e.id = '$exam'
                         WHERE a.teacherid = (SELECT id FROM user WHERE email = '$email')
                         AND a.yearid = '$year' 
                         AND a.departmentid = '$dept' 
                         AND a.sectionid = '$sec'";
                $result = mysqli_query($db_conn, $query);

                if(mysqli_num_rows($result) == 0) {
                    echo '<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                            <p>You are not allocated to assign marks for this class.</p>
                          </div>';
                } else {
                    $subject_info = mysqli_fetch_object($result);
            ?>
                    <!-- Marks Assignment Form -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="mb-6">
                            <h2 class="text-xl font-semibold text-gray-900">
                                Assign Marks for <?php echo $subject_info->subject_name; ?> - <?php echo $subject_info->examname; ?>
                            </h2>
                            <p class="text-sm text-gray-600">Total Marks: <?php echo $subject_info->totalmarks; ?></p>
                        </div>

                        <form method="POST" id="marksForm">
                            <input type="hidden" name="year" value="<?php echo $year; ?>">
                            <input type="hidden" name="dept" value="<?php echo $dept; ?>">
                            <input type="hidden" name="sec" value="<?php echo $sec; ?>">
                            <input type="hidden" name="exam" value="<?php echo $exam; ?>">

                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Roll No</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student Name</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Previous Marks</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Marks (Max: <?php echo $subject_info->totalmarks; ?>)</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php
                                        $query = "SELECT s.id, s.rollno, u.firstname, u.lastname, IFNULL(m.mark, '') as previous_mark
                                                 FROM student s 
                                                 JOIN user u ON s.id = u.id 
                                                 LEFT JOIN marks m ON s.id = m.studentid 
                                                    AND m.examid = '$exam' 
                                                    AND m.subjectid = '{$subject_info->subjectid}'
                                                 WHERE s.yearid = '$year' 
                                                 AND s.departmentid = '$dept' 
                                                 AND s.sectionid = '$sec' 
                                                 ORDER BY s.rollno";
                                        $students = mysqli_query($db_conn, $query);

                                        while($student = mysqli_fetch_object($students)):
                                        ?>
                                            <tr class="hover:bg-gray-50">
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    <?php echo $student->rollno; ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    <?php echo ucfirst($student->firstname) . ' ' . ucfirst($student->lastname); ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                    <?php echo $student->previous_mark ? $student->previous_mark : 'Not assigned'; ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <input type="number" 
                                                           name="marks[<?php echo $student->id; ?>]" 
                                                           value="<?php echo $student->previous_mark; ?>"
                                                           min="0" 
                                                           max="<?php echo $subject_info->totalmarks; ?>" 
                                                           class="w-24 rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                                                           required>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="mt-6 text-center">
                                <button type="submit" name="submitmarks" 
                                        class="px-6 py-2.5 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 focus:ring-4 focus:ring-green-300">
                                    Save Marks
                                </button>
                            </div>
                        </form>
                    </div>
            <?php 
                }
            endif; 
            ?>
        </main>
    </div>
</div>

<?php
// Process marks submission
if(isset($_POST['submitmarks'])) {
    $year = $_POST['year'];
    $dept = $_POST['dept'];
    $sec = $_POST['sec'];
    $exam = $_POST['exam'];
    
    // Get subject ID
    $email = $_SESSION['useremail'];
    $query = "SELECT subjectid FROM allotment 
              WHERE teacherid = (SELECT id FROM user WHERE email = '$email')
              AND yearid = '$year' 
              AND departmentid = '$dept' 
              AND sectionid = '$sec'";
    $result = mysqli_query($db_conn, $query);
    
    if($subject = mysqli_fetch_object($result)) {
        $subject_id = $subject->subjectid;
        
        foreach($_POST['marks'] as $student_id => $mark) {
            // Validate mark
            $mark = filter_var($mark, FILTER_VALIDATE_INT);
            if($mark === false || $mark < 0) continue;

            // Check if marks already exist
            $check_query = "SELECT id FROM marks 
                           WHERE studentid = '$student_id' 
                           AND examid = '$exam' 
                           AND subjectid = '$subject_id'";
            $check_result = mysqli_query($db_conn, $check_query);

            if(mysqli_num_rows($check_result) > 0) {
                // Update existing marks
                $update_query = "UPDATE marks 
                               SET mark = '$mark' 
                               WHERE studentid = '$student_id' 
                               AND examid = '$exam' 
                               AND subjectid = '$subject_id'";
                mysqli_query($db_conn, $update_query);
            } else {
                // Insert new marks
                $insert_query = "INSERT INTO marks (studentid, yearid, examid, subjectid, mark) 
                               VALUES ('$student_id', '$year', '$exam', '$subject_id', '$mark')";
                mysqli_query($db_conn, $insert_query);
            }
        }

        echo "<script>
                alert('Marks have been saved successfully!');
                window.location.href = 'grading.php';
              </script>";
    }
}
?>

<?php include("../public/footer.php"); ?>