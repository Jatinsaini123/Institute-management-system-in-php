<?php include("../actions/checkteacher.php") ?>
<?php include("../public/header.php")?>
<?php include("../includes/config.php") ?>

<div class="flex overflow-hidden bg-white">

<?php include("sidebar.php")?>

<div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>

<div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
    <main>
        <div class="pt-6 px-4 max-w-7xl mx-auto"> <!-- decreased width with max-w-7xl -->
            <div class="mt-4 w-full grid grid-cols-1 mb-4 md:grid-cols-2 xl:grid-cols-3 gap-4">

                <!-- Dashboard Cards -->
                <?php
                $cards = [
                    ['count' => 4, 'label' => 'Total Section Alloted', 'growth' => '14.6%'],
                    ['count' => 2, 'label' => 'Total Subject Teaching', 'growth' => '32.9%'],
                    ['count' => 1, 'label' => 'Total Department Alloted', 'growth' => '32.9%'],
                ];
                foreach ($cards as $card) {
                    echo '<div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <span class="text-2xl sm:text-3xl leading-none font-bold text-gray-900">'.$card['count'].'</span>
                                    <h3 class="text-base font-normal text-gray-500">'.$card['label'].'</h3>
                                </div>
                                <div class="ml-5 w-0 flex items-center justify-end flex-1 text-green-500 text-base font-bold">
                                    '.$card['growth'].'
                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                    </svg>
                                </div>
                            </div>
                          </div>';
                }
                ?>

            </div>

            <!-- Attendance Form -->
            <div class="w-full grid grid-cols-1 xl:grid-cols-2 2xl:grid-cols-4 gap-4 content-center">
                <div class="bg-white shadow rounded-lg p-4 sm:p-6 2xl:col-span-2">
                    <div class="mb-4 flex items-center justify-between">
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Take Attendance (<?= date("m-d-Y"); ?>)</h3>
                    </div>

                    <div class="flex flex-col mx-6">
                        <div class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm dark:border-gray-700 sm:p-6 dark:bg-gray-800">
                            <form action="" method="POST">
                                <div class="grid grid-cols-6 gap-6">
                                    <!-- Year -->
                                    <div class="col-span-6 sm:col-span-3 xl:col-span-2">
                                        <label for="year" class="block mb-2 text-sm font-medium text-gray-900">Year</label>
                                        <select name="year" id="year" class="form-select">
                                            <option value="NULL" selected>Select Year</option>
                                            <?php
                                            $years = mysqli_query($db_conn, "SELECT * FROM years");
                                            while ($y = mysqli_fetch_object($years)) {
                                                echo "<option value='{$y->id}'>{$y->year}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <!-- Department -->
                                    <div class="col-span-6 sm:col-span-3 xl:col-span-4">
                                        <label for="department" class="block mb-2 text-sm font-medium text-gray-900">Department</label>
                                        <select name="dept" id="department" class="form-select">
                                            <option value="NULL" selected>Select Department</option>
                                            <?php
                                            $departments = mysqli_query($db_conn, "SELECT * FROM department");
                                            while ($d = mysqli_fetch_object($departments)) {
                                                echo "<option value='{$d->id}'>".ucfirst($d->name)."</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <!-- Section -->
                                    <div class="col-span-6 sm:col-span-3 xl:col-span-2">
                                        <label for="section" class="block mb-2 text-sm font-medium text-gray-900">Section</label>
                                        <select name="sec" id="section" class="form-select">
                                            <option value="NULL" selected>Select Section</option>
                                            <?php
                                            $sections = mysqli_query($db_conn, "SELECT * FROM section");
                                            while ($s = mysqli_fetch_object($sections)) {
                                                echo "<option value='{$s->id}'>".ucfirst($s->name)."</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>

                                    <!-- Date -->
                                    <div class="col-span-3 sm:col-span-3 xl:col-span-2">
                                        <label for="date" class="block mb-2 text-sm font-medium text-gray-900">Date</label>
                                        <input type="date" name="selected_date" id="date" class="form-input" value="<?=date('Y-m-d')?>">
                                    </div>

                                    <!-- Button -->
                                    <div class="col-span-6 flex justify-center mt-4">
                                        <button type="submit" name="takeattendance" class="btn-primary">Take Attendance</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>

                <?php
                if (isset($_POST['takeattendance'])) {
                    $year = $_POST['year'];
                    $dept = $_POST['dept'];
                    $sec = $_POST['sec'];
                    $date = $_POST['selected_date'];
                ?>

                <!-- Attendance Table -->
                <div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 2xl:col-span-2">
                    <div class="flex flex-col mx-6">
                        <div class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm">
                            <form action="saveattendance.php" method="POST">
                                <input type="hidden" name="year" value="<?=$year?>">
                                <input type="hidden" name="dept" value="<?=$dept?>">
                                <input type="hidden" name="sec" value="<?=$sec?>">
                                <input type="hidden" name="date" value="<?=$date?>">

                                <div class="overflow-x-auto">
                                    <table class="table-auto min-w-full">
                                        <thead class="bg-gray-100">
                                            <tr>
                                                <th class="p-2">Student ID</th>
                                                <th class="p-2">Roll No.</th>
                                                <th class="p-2">Name</th>
                                                <th class="p-2">Attendance</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $students = mysqli_query($db_conn, "SELECT * FROM user,student WHERE user.user_type='student' AND user.id = student.id AND student.yearid = '$year' AND student.departmentid = '$dept' AND student.sectionid = '$sec'");
                                            while ($stu = mysqli_fetch_object($students)) {
                                                echo "<tr class='border-t'>
                                                    <td class='p-2'>{$stu->id}</td>
                                                    <td class='p-2'>{$stu->rollno}</td>
                                                    <td class='p-2'>{$stu->name}</td>
                                                    <td class='p-2'>
                                                        <select name='attendance[{$stu->id}]' class='form-select'>
                                                            <option value='Present'>Present</option>
                                                            <option value='Absent'>Absent</option>
                                                        </select>
                                                    </td>
                                                </tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="text-center mt-5">
                                    <button type="submit" name="save" class="btn-primary">Save Attendance</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php } ?>

            </div>
        </div>
    </main>
</div>

</div>

<!-- Custom CSS -->
<style>
    .form-select {
        background-color: #f9fafb;
        border: 1px solid #d1d5db;
        border-radius: 0.5rem;
        padding: 0.5rem;
        width: 100%;
    }
    .form-input {
        background-color: #f9fafb;
        border: 1px solid #d1d5db;
        border-radius: 0.5rem;
        padding: 0.5rem;
        width: 100%;
    }
    .btn-primary {
        background: linear-gradient(to right, #0ea5e9, #06b6d4);
        color: white;
        padding: 0.5rem 1.5rem;
        border-radius: 0.5rem;
        font-weight: 600;
        transition: background 0.3s ease;
    }
    .btn-primary:hover {
        background: linear-gradient(to right, #0284c7, #0891b2);
    }
</style>
