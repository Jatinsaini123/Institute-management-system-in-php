<?php
session_start();

// Fake default data — in a real app, you'd fetch this from the database
$_SESSION['teacher_name'] = $_SESSION['teacher_name'] ?? 'Mr. John Doe';
$_SESSION['teacher_email'] = $_SESSION['teacher_email'] ?? 'johndoe@example.com';
$_SESSION['teacher_subject'] = $_SESSION['teacher_subject'] ?? 'Mathematics';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['teacher_name'] = $_POST['name'] ?? $_SESSION['teacher_name'];
    $_SESSION['teacher_email'] = $_POST['email'] ?? $_SESSION['teacher_email'];
    $_SESSION['teacher_subject'] = $_POST['subject'] ?? $_SESSION['teacher_subject'];
    
    // Redirect to profile page after update
    header("Location: profile.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Teacher Profile</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

  <!-- Header -->
  <header class="bg-white shadow-md py-4 px-6 flex justify-between items-center">
    <h1 class="text-xl font-bold text-gray-800">Edit Profile</h1>
    <a href="profile.php" class="text-blue-500 hover:underline">Back to Profile</a>
  </header>

  <!-- Edit Form -->
  <main class="flex justify-center mt-10">
    <form method="POST" action="" class="bg-white p-8 rounded-lg shadow-md w-full max-w-lg">
      <h2 class="text-2xl font-semibold text-gray-700 text-center mb-6">Update Your Info</h2>

      <!-- Name -->
      <div class="mb-4">
        <label class="block text-gray-600 mb-1" for="name">Full Name</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($_SESSION['teacher_name']); ?>" required class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400">
      </div>

      <!-- Email -->
      <div class="mb-4">
        <label class="block text-gray-600 mb-1" for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['teacher_email']); ?>" required class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400">
      </div>

      <!-- Subject -->
      <div class="mb-6">
        <label class="block text-gray-600 mb-1" for="subject">Subject</label>
        <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($_SESSION['teacher_subject']); ?>" required class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400">
      </div>

      <!-- Submit Button -->
      <div class="text-center">
        <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded-md hover:bg-blue-600 transition duration-200">
          Save Changes
        </button>
      </div>
    </form>
  </main>

</body>
</html>
