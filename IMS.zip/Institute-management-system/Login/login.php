<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMS | Sign in</title>
    <link rel="stylesheet" href="loginstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    body {
        min-height: 100vh;
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
        color: #fff;
    }

    .background {
        position: absolute;
        width: 100%;
        height: 100%;
        background: url('background.jpg') no-repeat center center/cover;
        filter: blur(10px) brightness(0.5);
        z-index: -1;
    }

    .container {
        width: 900px;
        height: 550px;
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        border-radius: 15px;
        display: flex;
        overflow: hidden;
    }



    .content {
        width: 50%;
        background: linear-gradient(145deg, #1e1e2f, #282c34);
        padding: 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border-right: 1px solid rgba(255, 255, 255, 0.2);
    }

    .logo {
        font-size: 2.5rem;
        color: #00fff7;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 30px;
    }

    .text-sci h2 {
        font-size: 2rem;
        margin-bottom: 10px;
    }

    .text-sci p {
        font-size: 1rem;
        color: #ccc;
    }

    .logreg-box {
        width: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .form-box {
        width: 100%;
        padding: 40px;
        text-align: center;
    }

    .form-box h2 {
        font-size: 2rem;
        margin-bottom: 30px;
    }

    .input-box {
        position: relative;
        margin: 20px 0;
    }

    .input-box input {
        width: 100%;
        padding: 12px 40px 12px 40px;
        background: rgba(255, 255, 255, 0.05);
        border: none;
        outline: none;
        border-radius: 10px;
        color: #fff;
        font-size: 1rem;
        transition: 0.3s ease;
    }

    .input-box input:focus {
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0 0 10px rgba(0, 255, 255, 0.3);
    }

    .input-box label {
        position: absolute;
        left: 40px;
        top: 50%;
        transform: translateY(-50%);
        pointer-events: none;
        transition: 0.3s ease;
        color: #aaa;
    }

    .input-box input:focus ~ label,
    .input-box input:valid ~ label {
        top: -10px;
        left: 30px;
        font-size: 0.75rem;
        color: #00fff7;
    }

    .input-box .icon {
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        color: #00fff7;
        font-size: 1.2rem;
    }

    .btn {
        width: 100%;
        padding: 12px;
        background: linear-gradient(to right, #00fff7, #00d0ff);
        border: none;
        border-radius: 10px;
        color: #000;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .btn:hover {
        background: linear-gradient(to right, #00d0ff, #00fff7);
        transform: scale(1.05);
        box-shadow: 0 0 15px rgba(0, 255, 255, 0.5);
    }

    @media (max-width: 768px) {
        .container {
            flex-direction: column;
            height: auto;
        }

        .content, .logreg-box {
            width: 100%;
            height: auto;
        }
    }
    
</style> -->



</head>
<body>
    <div class="background"></div>

    <div class="container">
        <div class="content">
            <h2 class="logo"><i class='bx bxs-book-reader'></i>IMS</h2>
            <div class="text-sci">
                <h2>Welcome Back!</h2>
                <p>One-stop solution administration and academic management!</p>
                
            </div>
        </div>
         
        <div class="logreg-box">
            <div class="form-box login">
                <form action="../includes/logincheck.php" method="POST">
                    <h2>Sign In</h2>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-envelope' ></i></span>
                        <input type="email" name="useremail" required spellcheck="false" autocomplete="off">
                        <Placeholder>Email</Placeholder>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-lock-alt' ></i></span>
                        <input type="password" name="userpass" required>
                        <placeholder>Password</placeholder>
                    </div>
                    <button type="submit" name="login" class="btn">Login</button>
                    <div style="text-align:center; margin-top: 4%;">
                        <?php
                        error_reporting(0);
                        session_start();
                        session_destroy();
                        echo $_SESSION['loginMessage'];
                        ?>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <script src="srcipt.js"></script>
</body>
</html>